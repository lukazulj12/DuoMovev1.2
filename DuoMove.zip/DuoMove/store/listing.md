# Tekstovi za Google Play (Play Console → Rast → Prisutnost u trgovini → Glavni unos trgovine)

## Hrvatski (hr)
**Naziv (max 30):** DuoMove

**Kratki opis (max 80):** Duplikati, prijenos na novi mobitel i ispravak datuma fotografija – sve lokalno.

**Puni opis:**
DuoMove su tri alata u jednoj aplikaciji, bez oglasa, registracije i slanja podataka na internet.

ČIŠĆENJE DUPLIKATA
• Potpuno identične datoteke (SHA-256), čak i različitih naziva
• Iste fotografije različitih naziva i veličina (npr. WhatsApp kopije) i slične fotografije za ručnu provjeru
• Pravila koju kopiju zadržati: starija/novija, veća, veća rezolucija, prioritet mapa (npr. DCIM/Camera ostaje, Download se briše prvi)
• Pregled s povećanjem, konačni popis i potvrda prije brisanja; u svakoj grupi uvijek ostaje barem jedna datoteka; koš i oporavak

PRIJENOS NA NOVI MOBITEL
• Izravna Wi-Fi veza između dva mobitela – bez rutera, interneta i kabela
• Više paralelnih veza za najveću brzinu
• Odabir vrsta (fotografije, videozapisi, glazba, dokumenti, arhive, APK, aplikacije), vremenskog intervala i mapa
• Nastavlja se i kad se zaslon ugasi; kod za uparivanje štiti prijenos

ISPRAVAK DATUMA PO NAZIVU
• Fotografije i videozapisi kopirani na novi mobitel često dobiju današnji datum. DuoMove čita datum iz naziva
  (npr. IMG-20261028-WA0014.jpg, VID_20250705_105923.mp4) i vraća ispravan datum snimanja
• Prepoznaje DDMM i MMDD zapise, ručni oblici naziva, odabir mapa i vremenskog intervala

Hrvatski i engleski jezik.

## English (en-US)
**Title:** DuoMove

**Short description:** Duplicate cleaner, phone-to-phone transfer and photo date fixer – all offline.

**Full description:**
DuoMove is three tools in one app – no ads, no account, nothing sent to the internet.

DUPLICATE CLEANER
• Exact duplicates (SHA-256), even with different names
• The same photo with a different name or size (e.g. WhatsApp copies) and similar photos for manual review
• Rules for which copy to keep: older/newer, larger, higher resolution, folder priority (keep DCIM/Camera, delete from Download first)
• Zoomable review, final list and confirmation before deleting; at least one file always stays in every group; trash and recovery

TRANSFER TO A NEW PHONE
• Direct Wi-Fi connection between two phones – no router, internet or cable
• Multiple parallel connections for maximum speed
• Choose types (photos, videos, music, documents, archives, APK, apps), a date range and folders
• Keeps going with the screen off; a pairing code protects the transfer

FIX DATES BY FILE NAME
• Photos and videos copied to a new phone often get today's date. DuoMove reads the date from the name
  (e.g. IMG-20261028-WA0014.jpg, VID_20250705_105923.mp4) and restores the correct date taken
• Handles DDMM and MMDD orders, custom name formats, folder and date-range selection

Croatian and English.

**Kategorija / Category:** Alati (Tools)
