package hr.smartduplicatecleaner.core.logic

import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.ScannedFile

/**
 * Stanje oznaka za brisanje. Oznaka je globalna za datoteku (ne po grupi), pa ista datoteka
 * u dvije grupe uvijek ima isto stanje.
 *
 * Temeljno pravilo: u SVAKOJ grupi mora ostati barem jedna neoznačena datoteka.
 * Sve operacije čuvaju to pravilo; one koje bi ga prekršile ne mijenjaju stanje.
 */
class SelectionState(groups: List<DuplicateGroup>, marked: Set<String> = emptySet()) {

    val groups: List<DuplicateGroup> = groups.toList()
    private val groupById = this.groups.associateBy { it.id }
    private val groupsOfFile: Map<String, List<DuplicateGroup>> =
        this.groups.flatMap { g -> g.fileKeys.map { it to g } }.groupBy({ it.first }, { it.second })

    private val _marked = LinkedHashSet<String>(marked.filter { it in groupsOfFile })
    val marked: Set<String> get() = _marked.toSet()

    init {
        // Ako učitano stanje krši pravilo (npr. oštećena baza), poništi oznake u toj grupi.
        for (g in this.groups) if (g.fileKeys.all { it in _marked }) g.fileKeys.forEach { _marked.remove(it) }
    }

    fun isMarked(key: String) = key in _marked

    fun groupsContaining(key: String): List<DuplicateGroup> = groupsOfFile[key].orEmpty()

    /** Smije li se datoteka označiti a da nijedna grupa ne ostane bez datoteke za čuvanje. */
    fun canMark(key: String): Boolean =
        groupsContaining(key).all { g -> g.fileKeys.any { it != key && it !in _marked } }

    enum class Result { OK, BLOCKED_LAST_FILE, UNKNOWN_FILE }

    fun setMarked(key: String, mark: Boolean): Result {
        if (key !in groupsOfFile) return Result.UNKNOWN_FILE
        if (!mark) { _marked.remove(key); return Result.OK }
        if (!canMark(key)) return Result.BLOCKED_LAST_FILE
        _marked.add(key)
        return Result.OK
    }

    fun toggle(key: String): Result = setMarked(key, !isMarked(key))

    /**
     * "Zadrži samo ovu": odznači odabranu datoteku i označi ostale u grupi.
     * Datoteke čije bi označavanje ostavilo neku drugu grupu bez čuvane datoteke preskaču se.
     * @return broj preskočenih datoteka
     */
    fun keepOnly(groupId: String, keepKey: String): Int {
        val group = groupById[groupId] ?: return 0
        if (keepKey !in group.fileKeys) return 0
        _marked.remove(keepKey)
        var skipped = 0
        for (k in group.fileKeys) {
            if (k == keepKey) continue
            if (setMarked(k, true) != Result.OK) skipped++
        }
        return skipped
    }

    fun clearGroup(groupId: String) {
        groupById[groupId]?.fileKeys?.forEach { _marked.remove(it) }
    }

    fun clearAll() = _marked.clear()

    /**
     * Primjena automatskih prijedloga.
     * @param onlyConfirmed true = samo grupe potpuno identičnih datoteka (SHA-256)
     * @return broj označenih datoteka
     */
    fun applySuggestions(decisions: Collection<GroupDecision>, onlyConfirmed: Boolean): Int {
        var count = 0
        for (d in decisions) {
            val g = groupById[d.groupId] ?: continue
            if (!g.allowsAutoSuggestion || d.needsManual) continue
            if (onlyConfirmed && g.type != GroupType.EXACT) continue
            for (key in d.suggestedDeleteKeys) {
                if (!isMarked(key) && setMarked(key, true) == Result.OK) count++
            }
        }
        return count
    }

    /** Grupe u kojima bi bile označene sve datoteke (ne bi se smjelo dogoditi). */
    fun violations(): List<DuplicateGroup> = groups.filter { g -> g.fileKeys.all { it in _marked } }
}

/** Konačni, nepromjenjivi plan brisanja koji korisnik potvrđuje. */
data class DeletionPlan(val items: List<ScannedFile>) {
    val totalBytes: Long get() = items.sumOf { it.sizeBytes }
    val count: Int get() = items.size
    val keys: Set<String> get() = items.map { it.key }.toSet()
}

sealed class PlanResult {
    data class Ready(val plan: DeletionPlan) : PlanResult()
    data class Rejected(val emptyGroups: List<DuplicateGroup>, val missingFiles: List<String>) : PlanResult()
    data object Empty : PlanResult()
}

object DeletionPlanner {
    /**
     * Izrada plana. Plan se odbija ako bi ijedna grupa ostala bez datoteke ili ako
     * označena datoteka nije poznata (zaštita od brisanja nečega što nije na popisu).
     */
    fun build(state: SelectionState, files: Map<String, ScannedFile>): PlanResult {
        val marked = state.marked
        if (marked.isEmpty()) return PlanResult.Empty
        val emptyGroups = state.violations()
        val missing = marked.filter { it !in files }
        if (emptyGroups.isNotEmpty() || missing.isNotEmpty()) return PlanResult.Rejected(emptyGroups, missing)
        val items = marked.map { files.getValue(it) }.sortedWith(compareBy({ it.relativeDir }, { it.name }))
        return PlanResult.Ready(DeletionPlan(items))
    }
}
