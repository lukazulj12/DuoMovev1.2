package hr.smartduplicatecleaner.core.dates

/**
 * Ručno zadani oblik naziva datoteke, npr. "IMG-yyyyMMdd-WA*" ili "Screenshot_yyyy-MM-dd-HH-mm-ss*".
 *
 * Oznake (razlikuju se velika i mala slova):
 *  yyyy ili GGGG – godina (4 znamenke), yy ili GG – godina (2 znamenke, 20xx)
 *  MM – mjesec, dd ili DD – dan, HH ili hh – sat, mm – minute, ss – sekunde
 *  *  – bilo koji niz znakova, ? – jedan bilo koji znak, # – jedna znamenka
 * Ostali znakovi uspoređuju se doslovno (bez obzira na velika/mala slova).
 * Uzorak mora obuhvatiti CIJELI naziv (s ekstenzijom ili bez nje) – za ostatak koristite *.
 */
class NamePattern private constructor(val text: String, private val regex: Regex, private val tokens: List<Token>) {

    enum class Token { YEAR4, YEAR2, MONTH, DAY, HOUR, MINUTE, SECOND }

    data class Fields(val year: Int, val month: Int, val day: Int, val hour: Int?, val minute: Int?, val second: Int?)

    /** Uspoređuje uzorak s nazivom s ekstenzijom i bez nje. */
    fun match(fileName: String): Fields? {
        val withoutExt = fileName.substringBeforeLast('.', fileName)
        val m = regex.matchEntire(fileName) ?: regex.matchEntire(withoutExt) ?: return null
        var year = -1
        var month = -1
        var day = -1
        var hour: Int? = null
        var minute: Int? = null
        var second: Int? = null
        tokens.forEachIndexed { i, t ->
            val v = m.groupValues[i + 1].toInt()
            when (t) {
                Token.YEAR4 -> year = v
                Token.YEAR2 -> year = 2000 + v
                Token.MONTH -> month = v
                Token.DAY -> day = v
                Token.HOUR -> hour = v
                Token.MINUTE -> minute = v
                Token.SECOND -> second = v
            }
        }
        return Fields(year, month, day, hour, minute, second)
    }

    /** Pogreška pri tumačenju uzorka. */
    class InvalidPatternException(val reason: Reason) : IllegalArgumentException(reason.name)

    enum class Reason { EMPTY, MISSING_YEAR, MISSING_MONTH, MISSING_DAY, DUPLICATE_TOKEN }

    companion object {
        private val TOKENS: List<Pair<String, Token>> = listOf(
            "yyyy" to Token.YEAR4, "GGGG" to Token.YEAR4,
            "yy" to Token.YEAR2, "GG" to Token.YEAR2,
            "MM" to Token.MONTH, "dd" to Token.DAY, "DD" to Token.DAY,
            "HH" to Token.HOUR, "hh" to Token.HOUR,
            "mm" to Token.MINUTE, "ss" to Token.SECOND
        )

        /** @throws InvalidPatternException ako uzorak nije ispravan */
        fun compile(text: String): NamePattern {
            val t = text.trim()
            if (t.isEmpty()) throw InvalidPatternException(Reason.EMPTY)
            val sb = StringBuilder()
            val literal = StringBuilder()
            val tokens = mutableListOf<Token>()
            fun flush() {
                if (literal.isNotEmpty()) { sb.append(Regex.escape(literal.toString())); literal.clear() }
            }
            var i = 0
            while (i < t.length) {
                val token = TOKENS.firstOrNull { t.startsWith(it.first, i) }
                when {
                    token != null -> {
                        flush()
                        val type = token.second
                        val isYear = type == Token.YEAR4 || type == Token.YEAR2
                        val clash = tokens.any { it == type || (isYear && (it == Token.YEAR4 || it == Token.YEAR2)) }
                        if (clash) throw InvalidPatternException(Reason.DUPLICATE_TOKEN)
                        tokens += type
                        sb.append(if (type == Token.YEAR4) "(\\d{4})" else "(\\d{2})")
                        i += token.first.length
                    }
                    t[i] == '*' -> { flush(); sb.append(".*?"); i++ }
                    t[i] == '?' -> { flush(); sb.append("."); i++ }
                    t[i] == '#' -> { flush(); sb.append("\\d"); i++ }
                    else -> { literal.append(t[i]); i++ }
                }
            }
            flush()
            if (tokens.none { it == Token.YEAR4 || it == Token.YEAR2 }) throw InvalidPatternException(Reason.MISSING_YEAR)
            if (Token.MONTH !in tokens) throw InvalidPatternException(Reason.MISSING_MONTH)
            if (Token.DAY !in tokens) throw InvalidPatternException(Reason.MISSING_DAY)
            return NamePattern(t, Regex(sb.toString(), RegexOption.IGNORE_CASE), tokens)
        }

        fun compileOrNull(text: String): NamePattern? = try { compile(text) } catch (e: InvalidPatternException) { null }
    }
}
