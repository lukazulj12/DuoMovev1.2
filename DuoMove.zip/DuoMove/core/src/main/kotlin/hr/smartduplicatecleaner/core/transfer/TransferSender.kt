package hr.smartduplicatecleaner.core.transfer

import hr.smartduplicatecleaner.core.scan.CancelToken
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Collections
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Pošiljatelj. Otvara kontrolnu vezu (provjera koda, popis datoteka, provjera prostora na primatelju),
 * zatim [streams] paralelnih podatkovnih veza – više istovremenih TCP veza bolje iskorištava Wi-Fi
 * i ubrzava prijenos mnogo malih datoteka. Velike datoteke šalju se prve radi ravnomjernog opterećenja.
 */
class TransferSender(
    private val host: String,
    private val port: Int,
    code: String,
    private val deviceName: String = "",
    private val streams: Int = 4,
    private val connectTimeoutMs: Int = 10_000,
    private val socketFactory: () -> Socket = { Socket() }
) {
    private val key = PairingCode.authKey(code)

    private class Conn(val socket: Socket) : Closeable {
        val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), 64 * 1024))
        val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), Proto.BUFFER))
        override fun close() { try { socket.close() } catch (e: Exception) { } }
    }

    private class Stop : RuntimeException()

    fun send(
        items: List<TransferItem>,
        source: TransferSource,
        cancel: CancelToken = CancelToken.NONE,
        onProgress: (TransferProgress) -> Unit = {}
    ): TransferResult {
        val started = System.currentTimeMillis()
        val control = connect(Proto.TYPE_CONTROL)
        try {
            control.out.writeUTF(deviceName.take(60))
            control.out.writeInt(items.size)
            items.forEach { Proto.writeItem(control.out, it) }
            control.out.flush()

            val status = control.inp.readUnsignedByte()
            val free = control.inp.readLong()
            if (status == Proto.NO_SPACE) throw TransferException(TransferException.Reason.NO_SPACE, free)
            if (status != Proto.OK) throw TransferException(TransferException.Reason.PROTOCOL)
            val skipIds = HashSet<Int>()
            repeat(control.inp.readInt()) { skipIds += control.inp.readInt() }

            val skipped = items.filter { it.id in skipIds }
            val toSend = items.filter { it.id !in skipIds }.sortedByDescending { it.size }
            val total = toSend.sumOf { it.size }
            val queue = ConcurrentLinkedQueue(toSend)
            val ok = Collections.synchronizedList(mutableListOf<TransferItem>())
            val failed = Collections.synchronizedList(mutableListOf<Pair<TransferItem, String>>())
            val bytes = AtomicLong()
            val done = AtomicInteger()
            val lastEmit = AtomicLong()

            fun progress(force: Boolean = false) {
                val now = System.currentTimeMillis()
                val last = lastEmit.get()
                if (force || now - last >= 200 && lastEmit.compareAndSet(last, now)) {
                    onProgress(TransferProgress(done.get(), toSend.size, bytes.get(), total, failed.size, started))
                }
            }
            progress(force = true)

            val workers = (0 until streams.coerceIn(1, 8).coerceAtMost(maxOf(1, toSend.size))).map {
                Thread({
                    var conn: Conn? = null
                    var inFlight: TransferItem? = null
                    try {
                        conn = connect(Proto.TYPE_DATA)
                        val buf = ByteArray(Proto.BUFFER)
                        while (!cancel.isCancelled()) {
                            val item = queue.poll() ?: break
                            inFlight = item
                            val error = sendOne(conn, item, source, buf, cancel) { n -> bytes.addAndGet(n.toLong()); progress() }
                            if (error == null) ok += item else failed += item to error
                            done.incrementAndGet()
                            inFlight = null
                            progress()
                        }
                        conn.out.writeInt(Proto.END)
                        conn.out.flush()
                    } catch (e: Exception) {
                        inFlight?.let { failed += it to (if (cancel.isCancelled()) "cancelled" else "connection"); done.incrementAndGet() }
                    } finally {
                        conn?.close()
                    }
                }, "duomove-send-$it").apply { start() }
            }
            workers.forEach { it.join() }

            // Što je ostalo u redu (sve veze prekinute ili otkazano) – neuspjelo.
            val cancelled = cancel.isCancelled()
            while (true) {
                val item = queue.poll() ?: break
                failed += item to (if (cancelled) "cancelled" else "connection")
                done.incrementAndGet()
            }
            progress(force = true)

            // Pri otkazivanju se DONE ne šalje – primatelj tada sesiju bilježi kao prekinutu.
            if (!cancelled) try {
                control.out.writeByte(Proto.DONE)
                control.out.flush()
                control.inp.readInt(); control.inp.readInt()
            } catch (e: Exception) {
                // Sažetak primatelja je samo potvrda; rezultat se temelji na potvrdama za svaku datoteku.
            }
            return TransferResult(ok.toList(), failed.toList(), skipped, bytes.get(), System.currentTimeMillis() - started, cancelled)
        } catch (e: TransferException) {
            throw e
        } catch (e: Exception) {
            throw TransferException(if (cancel.isCancelled()) TransferException.Reason.CANCELLED else TransferException.Reason.CONNECTION, cause = e)
        } finally {
            control.close()
        }
    }

    /** @return null ako je uspjelo, inače razlog */
    private fun sendOne(conn: Conn, item: TransferItem, source: TransferSource, buf: ByteArray, cancel: CancelToken, counted: (Int) -> Unit): String? {
        val out = conn.out
        out.writeInt(item.id)
        out.writeLong(item.size)
        var sent = 0L
        var sourceError: String? = null
        var input: InputStream? = try { source.open(item) } catch (e: Exception) { sourceError = "open: " + (e.message ?: e.javaClass.simpleName); null }
        try {
            while (sent < item.size) {
                if (cancel.isCancelled()) throw Stop()
                val want = minOf(buf.size.toLong(), item.size - sent).toInt()
                val n = if (input == null) -1 else try {
                    input.read(buf, 0, want)
                } catch (e: Exception) {
                    sourceError = "read: " + (e.message ?: e.javaClass.simpleName); -1
                }
                if (n < 0) break
                if (n == 0) continue
                out.write(buf, 0, n)
                sent += n
                counted(n)
            }
        } finally {
            try { input?.close() } catch (e: Exception) { }
            input = null
        }
        if (sent < item.size) {
            // Izvor je kraći ili nedostupan – popuna nulama da veza ostane usklađena; primatelj odbacuje datoteku.
            if (sourceError == null) sourceError = "short"
            java.util.Arrays.fill(buf, 0.toByte())
            while (sent < item.size) {
                if (cancel.isCancelled()) throw Stop()
                val n = minOf(buf.size.toLong(), item.size - sent).toInt()
                out.write(buf, 0, n)
                sent += n
            }
        }
        out.writeByte(if (sourceError == null) 0 else 1)
        out.flush()
        val ack = conn.inp.readUnsignedByte()
        return sourceError ?: if (ack == 0) null else "receiver"
    }

    private fun connect(type: Int): Conn {
        val socket = socketFactory()
        try {
            socket.tcpNoDelay = true
            socket.sendBufferSize = Proto.SOCKET_BUFFER
            socket.receiveBufferSize = 256 * 1024
            socket.connect(InetSocketAddress(host, port), connectTimeoutMs)
            socket.soTimeout = 120_000
        } catch (e: Exception) {
            try { socket.close() } catch (x: Exception) { }
            throw TransferException(TransferException.Reason.CONNECTION, cause = e)
        }
        val conn = Conn(socket)
        try {
            conn.out.write(Proto.MAGIC)
            conn.out.writeByte(type)
            conn.out.flush()
            val nonce = ByteArray(16)
            conn.inp.readFully(nonce)
            conn.out.write(Proto.hmac(key, Proto.label(type), nonce))
            conn.out.flush()
            when (conn.inp.readUnsignedByte()) {
                Proto.OK -> Unit
                Proto.AUTH_FAIL -> throw TransferException(TransferException.Reason.AUTH_FAILED)
                Proto.BUSY -> throw TransferException(TransferException.Reason.BUSY)
                else -> throw TransferException(TransferException.Reason.PROTOCOL)
            }
            if (type == Proto.TYPE_CONTROL) socket.soTimeout = 0 // čekanje na kraj prijenosa može trajati dugo
            return conn
        } catch (e: TransferException) {
            conn.close(); throw e
        } catch (e: Exception) {
            conn.close(); throw TransferException(TransferException.Reason.CONNECTION, cause = e)
        }
    }
}
