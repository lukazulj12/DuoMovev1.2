package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.media.FileRandomAccessIO
import hr.smartduplicatecleaner.core.media.Mp4Dates
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.RandomAccessFile

class Mp4DatesTest {
    private fun box(type: String, payload: ByteArray, large: Boolean = false): ByteArray {
        val bos = ByteArrayOutputStream()
        val out = DataOutputStream(bos)
        if (large) { out.writeInt(1); out.write(type.toByteArray()); out.writeLong(16L + payload.size) }
        else { out.writeInt(8 + payload.size); out.write(type.toByteArray()) }
        out.write(payload)
        return bos.toByteArray()
    }

    private fun fullBox(version: Int, creation: Long, rest: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        val out = DataOutputStream(bos)
        out.writeByte(version); out.write(byteArrayOf(0, 0, 0))
        if (version == 1) { out.writeLong(creation); out.writeLong(creation) } else { out.writeInt(creation.toInt()); out.writeInt(creation.toInt()) }
        out.write(ByteArray(rest) { 7 })
        return bos.toByteArray()
    }

    private fun sampleMp4(moovLast: Boolean): ByteArray {
        val old = 3_000_000_000L // 2001. godina u sekundama od 1904.
        val trak = box("trak", box("tkhd", fullBox(0, old, 60)) + box("mdia", box("mdhd", fullBox(1, old, 8)) + box("hdlr", ByteArray(20))))
        val moov = box("moov", box("mvhd", fullBox(0, old, 80)) + trak + box("udta", ByteArray(12)))
        val ftyp = box("ftyp", "isom0000mp41".toByteArray())
        val mdat = box("mdat", ByteArray(5000) { (it % 251).toByte() }, large = true)
        return if (moovLast) ftyp + mdat + moov else ftyp + moov + mdat
    }

    private fun withFile(bytes: ByteArray, block: (File) -> Unit) {
        val f = File.createTempFile("mp4test", ".mp4")
        try { f.writeBytes(bytes); block(f) } finally { f.delete() }
    }

    @Test
    fun writesAllDateFields_inPlace_keepingSizeAndMediaData() {
        for (moovLast in listOf(false, true)) {
            val original = sampleMp4(moovLast)
            withFile(original) { f ->
                val target = 1_751_712_000_000L // 5. 7. 2025. 10:40 UTC
                val changed = RandomAccessFile(f, "rw").use { Mp4Dates.write(FileRandomAccessIO(it), target) }
                assertEquals(3, changed) // mvhd, tkhd, mdhd
                val after = f.readBytes()
                assertEquals(original.size, after.size)
                assertEquals(target, RandomAccessFile(f, "r").use { Mp4Dates.read(FileRandomAccessIO(it)) })
                // Sadržaj mdat nepromijenjen.
                val mdat = ByteArray(5000) { (it % 251).toByte() }
                val idx = after.indices.first { i -> after.copyOfRange(i, i + 4).contentEquals("mdat".toByteArray()) }
                assertArrayEquals(mdat, after.copyOfRange(idx + 12, idx + 12 + 5000))
            }
        }
    }

    @Test
    fun notMp4_isRejected_withoutChanges() {
        val jpeg = ByteArray(2000) { (it * 7).toByte() }.also { it[0] = 0xFF.toByte(); it[1] = 0xD8.toByte() }
        withFile(jpeg) { f ->
            try {
                RandomAccessFile(f, "rw").use { Mp4Dates.write(FileRandomAccessIO(it), 1_000_000_000_000L) }
                fail("očekivana iznimka")
            } catch (e: Mp4Dates.NotMp4Exception) { }
            assertArrayEquals(jpeg, f.readBytes())
            assertNull(RandomAccessFile(f, "r").use { Mp4Dates.read(FileRandomAccessIO(it)) })
        }
    }
}
