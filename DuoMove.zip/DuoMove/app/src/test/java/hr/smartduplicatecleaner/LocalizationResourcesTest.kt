package hr.smartduplicatecleaner

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Scenarij 13 (dio koji se može provjeriti bez uređaja): svaki tekst postoji i na hrvatskom
 * i na engleskom, s istim parametrima formata. Testovi se izvršavaju iz mape modula "app".
 */
class LocalizationResourcesTest {
    private fun load(path: String): Map<String, String> {
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(File(path))
        val nodes = doc.getElementsByTagName("string")
        return (0 until nodes.length).associate { i ->
            val n = nodes.item(i)
            n.attributes.getNamedItem("name").nodeValue to n.textContent
        }
    }

    private val en = load("src/main/res/values/strings.xml")
    private val hr = load("src/main/res/values-hr/strings.xml")
    private val spec = Regex("%(\\d+\\$)?[sdf%]")

    @Test
    fun everyStringIsTranslated() {
        val missing = en.keys.filter { it != "app_name" && it !in hr }
        assertTrue("Nedostaju prijevodi: $missing", missing.isEmpty())
    }

    @Test
    fun formatArgumentsMatch() {
        for ((k, v) in en) {
            val h = hr[k] ?: continue
            assertEquals("Formati se razlikuju za $k", spec.findAll(v).map { it.value }.sorted().toList(), spec.findAll(h).map { it.value }.sorted().toList())
        }
    }

    @Test
    fun keyCroatianTermsPresent() {
        val values = hr.values.toSet()
        listOf("Skeniraj datoteke", "Pronađeni duplikati", "Zadrži ovu datoteku", "PREDLOŽENO ZA BRISANJE",
            "Datum snimanja", "Datum posljednje izmjene", "Potvrdi brisanje").forEach {
            assertTrue("Nedostaje izraz: $it", it in values)
        }
    }
}
