package hr.smartduplicatecleaner.transfer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import hr.smartduplicatecleaner.BuildConfig

/**
 * Instalacija primljenih aplikacija (samo inačica "full" – Google Play ne dopušta instaliranje APK-ova
 * aplikacijama kojima to nije osnovna namjena). Android za svaku aplikaciju traži potvrdu korisnika.
 */
object ApkInstaller {
    val isAvailable: Boolean get() = BuildConfig.ALLOW_INSTALL

    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    fun permissionIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))

    /** Instalira jedan ili više APK-ova iste aplikacije (base.apk + dijelovi). */
    fun install(context: Context, app: ReceivedApp) {
        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        val sessionId = installer.createSession(params)
        installer.openSession(sessionId).use { session ->
            app.apks.forEachIndexed { i, uri ->
                context.contentResolver.openInputStream(uri)?.use { input ->
                    session.openWrite("apk_$i.apk", 0, -1).use { out ->
                        input.copyTo(out, 1 shl 20)
                        session.fsync(out)
                    }
                } ?: throw java.io.IOException("open $uri")
            }
            val intent = Intent(context, InstallResultReceiver::class.java)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
            val pi = PendingIntent.getBroadcast(context, sessionId, intent, flags)
            session.commit(pi.intentSender)
        }
    }
}

/** Prima ishod instalacije; kad Android traži potvrdu korisnika, otvara sistemski dijalog. */
class InstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            val confirm: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_INTENT)
            }
            confirm?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { context.startActivity(it) } catch (e: Exception) { }
            }
        }
    }
}
