package hr.smartduplicatecleaner.transfer

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.exifinterface.media.ExifInterface
import hr.smartduplicatecleaner.core.media.Mp4Dates
import hr.smartduplicatecleaner.datefix.DateWriter
import hr.smartduplicatecleaner.core.logic.FileClassifier
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.core.scan.CancelToken
import hr.smartduplicatecleaner.core.scan.FileSource
import hr.smartduplicatecleaner.core.transfer.IncomingFile
import hr.smartduplicatecleaner.core.transfer.TransferCategory
import hr.smartduplicatecleaner.core.transfer.TransferClassifier
import hr.smartduplicatecleaner.core.transfer.TransferItem
import hr.smartduplicatecleaner.core.transfer.TransferSink
import hr.smartduplicatecleaner.core.transfer.TransferSource
import hr.smartduplicatecleaner.storage.FileSystemSource
import hr.smartduplicatecleaner.storage.MediaStoreSource
import hr.smartduplicatecleaner.storage.SafTreeSource
import hr.smartduplicatecleaner.storage.StorageAccess
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Popis datoteka za slanje prema odabranim vrstama i vremenskom intervalu. */
object TransferScanner {

    fun scan(
        context: Context,
        categories: Set<TransferCategory>,
        from: Long?,
        to: Long?,
        safTrees: Set<String>
    ): List<TransferItem> {
        val sources = mutableListOf<FileSource>()
        val media = buildSet {
            if (TransferCategory.PHOTOS in categories) add(FileCategory.IMAGE)
            if (TransferCategory.VIDEOS in categories) add(FileCategory.VIDEO)
            if (TransferCategory.AUDIO in categories) add(FileCategory.AUDIO)
        }
        if (media.isNotEmpty()) sources += MediaStoreSource(context, media)
        val wantsFiles = categories.any { it != TransferCategory.APPS }
        if (wantsFiles && StorageAccess.hasAllFilesAccess()) sources += FileSystemSource(context)
        if (wantsFiles) safTrees.forEach { sources += SafTreeSource(context, it) }

        val unique = LinkedHashMap<String, ScannedFile>()
        for (s in sources) {
            try {
                s.enumerate(CancelToken.NONE, { f -> unique.putIfAbsent(f.key, f) }, { })
            } catch (e: Exception) {
                // Izvor bez dopuštenja ili nedostupan – preskače se.
            }
        }
        val result = mutableListOf<TransferItem>()
        for (f in unique.values) {
            if (f.sizeBytes <= 0) continue
            val cat = TransferClassifier.of(f)
            if (cat !in categories) continue
            val created = listOfNotNull(f.dateTakenMillis, f.dateModifiedMillis).filter { it > 0 }.minOrNull()
            if ((from != null || to != null) && (created == null || (from != null && created < from) || (to != null && created > to))) continue
            result += TransferItem(
                id = result.size,
                relativeDir = f.relativeDir,
                name = f.name,
                size = f.sizeBytes,
                modified = f.dateModifiedMillis,
                taken = f.dateTakenMillis,
                category = cat,
                mime = f.mimeType,
                sourceRef = if (f.source == SourceType.FILE_SYSTEM) f.absolutePath ?: f.uri else f.uri
            )
        }
        if (TransferCategory.APPS in categories) result += apps(context, startId = result.size)
        return result
    }

    /**
     * Instalirane aplikacije (one s ikonom u izborniku, bez sistemskih). Kopiraju se njihove APK datoteke
     * (uključujući dijelove "split APK"); podaci aplikacija ne mogu se prenijeti (Androidova zaštita).
     */
    @Suppress("DEPRECATION")
    fun apps(context: Context, startId: Int): List<TransferItem> {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val packages = pm.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName }.distinct()
        val result = mutableListOf<TransferItem>()
        var id = startId
        for (pkg in packages) {
            if (pkg == context.packageName) continue
            val ai = try { pm.getApplicationInfo(pkg, 0) } catch (e: Exception) { continue }
            val system = ai.flags and ApplicationInfo.FLAG_SYSTEM != 0 && ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP == 0
            if (system) continue
            val label = safeName(ai.loadLabel(pm).toString()).ifEmpty { pkg }
            val files = listOfNotNull(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
            val single = files.size == 1
            for (path in files) {
                val f = File(path)
                if (!f.canRead()) continue
                val name = if (single) "$label.apk" else if (path == ai.sourceDir) "base.apk" else f.name
                result += TransferItem(
                    id = id++,
                    relativeDir = if (single) "Apps/" else "Apps/$label/",
                    name = name,
                    size = f.length(),
                    modified = f.lastModified(),
                    taken = null,
                    category = TransferCategory.APPS,
                    mime = APK_MIME,
                    sourceRef = path
                )
            }
        }
        return result
    }

    private fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|\\u0000]"), "_").trim()

    const val APK_MIME = "application/vnd.android.package-archive"
}

/** Čitanje datoteka na pošiljatelju (MediaStore/SAF URI ili putanja). */
class AndroidTransferSource(private val context: Context) : TransferSource {
    override fun open(item: TransferItem): InputStream {
        val ref = item.sourceRef
        if (!ref.startsWith("content://")) return FileInputStream(File(ref))
        var uri = Uri.parse(ref)
        // Izvorni bajtovi fotografija i videozapisa (uključujući lokaciju u EXIF-u), ako je dopušteno.
        if (uri.authority == MediaStore.AUTHORITY && StorageAccess.hasMediaLocation(context) &&
            (item.category == TransferCategory.PHOTOS || item.category == TransferCategory.VIDEOS)
        ) {
            try { uri = MediaStore.setRequireOriginal(uri) } catch (e: Exception) { }
        }
        return try {
            context.contentResolver.openInputStream(uri) ?: throw IOException("open")
        } catch (e: UnsupportedOperationException) {
            context.contentResolver.openInputStream(Uri.parse(ref)) ?: throw IOException("open")
        } catch (e: SecurityException) {
            context.contentResolver.openInputStream(Uri.parse(ref)) ?: throw IOException("open")
        }
    }
}

/** Primljena aplikacija (APK datoteke) – za instalaciju nakon prijenosa. */
data class ReceivedApp(val label: String, val apks: List<Uri>)

/**
 * Spremanje primljenih datoteka u mapu DuoMove, s podmapom za svaku vrstu
 * (npr. DuoMove/Fotografije, DuoMove/Videozapisi, DuoMove/Dokumenti …).
 *  - Uz "Pristup svim datotekama": /Interna memorija/DuoMove/…, s izvornim datumom izmjene.
 *  - Inače (Androidova pravila pohrane dopuštaju aplikacijama sve vrste datoteka samo u mapi Download):
 *    /Interna memorija/Download/DuoMove/….
 * Izvorni datum se čuva gdje god je moguće: datum izmjene datoteke, a fotografijama i videozapisima bez
 * datuma snimanja upisuje se izvorni datum u EXIF / MP4 – tako ih i galerija prikazuje pod pravim datumom.
 */
class AndroidTransferSink(
    private val context: Context,
    private val skipExisting: Boolean,
    private val keepSubfolders: Boolean,
    private val folderName: (TransferCategory) -> String
) : TransferSink {
    private val resolver get() = context.contentResolver
    private val direct = StorageAccess.hasAllFilesAccess()
    private val root: File = Environment.getExternalStorageDirectory()
    private val appFiles = java.util.concurrent.ConcurrentHashMap<String, MutableList<Pair<String, Uri>>>()

    /** Aplikacije primljene u ovoj sesiji. */
    fun receivedApps(): List<ReceivedApp> = appFiles.map { (label, files) ->
        // base.apk ide prvi pri instalaciji podijeljenih APK-ova.
        ReceivedApp(label, synchronized(files) { files.sortedBy { if (it.first == "base.apk") 0 else 1 }.map { it.second } })
    }

    private fun rememberApp(item: TransferItem, uri: Uri) {
        appFiles.getOrPut(appLabel(item)) { java.util.Collections.synchronizedList(mutableListOf()) }.add(item.name to uri)
    }

    override fun freeBytes(): Long = try {
        StatFs(root.absolutePath).availableBytes - RESERVE
    } catch (e: Exception) {
        Long.MAX_VALUE
    }

    /** Relativna mapa odredišta, npr. "Download/DuoMove/Fotografije/" ili "DuoMove/Fotografije/Camera/". */
    private fun targetDir(item: TransferItem): String {
        val base = (if (direct) DIRECT_ROOT else MEDIA_ROOT) + safe(folderName(item.category)) + "/"
        return when {
            item.category == TransferCategory.APPS -> base + item.relativeDir.removePrefix("Apps/")
            keepSubfolders -> base + item.relativeDir.trimEnd('/').substringAfterLast('/').let { if (it.isEmpty()) "" else safe(it) + "/" }
            else -> base
        }
    }

    private fun safe(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "_" }

    private fun mime(item: TransferItem): String {
        item.mime?.takeIf { it.contains('/') }?.let { return it }
        val ext = FileClassifier.extension(item.name)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    override fun shouldSkip(item: TransferItem): Boolean {
        if (!skipExisting) return false
        return try {
            if (direct) {
                val f = File(File(root, targetDir(item)), item.name)
                f.exists() && f.length() == item.size
            } else {
                resolver.query(
                    MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.SIZE}=?",
                    arrayOf(targetDir(item), item.name, item.size.toString()), null
                )?.use { it.count > 0 } ?: false
            }
        } catch (e: Exception) {
            false
        }
    }

    override fun create(item: TransferItem): IncomingFile = if (direct) createDirect(item) else createMedia(item)

    private fun appLabel(item: TransferItem): String =
        item.relativeDir.removePrefix("Apps/").trimEnd('/').ifEmpty { item.name.removeSuffix(".apk") }

    private fun createDirect(item: TransferItem): IncomingFile {
        val dir = File(root, targetDir(item)).apply { mkdirs() }
        var target = File(dir, item.name)
        if (target.exists()) target = uniqueFile(dir, item.name)
        val part = File(dir, "." + target.name + ".duomove-part")
        val out = BufferedOutputStream(FileOutputStream(part), 1 shl 20)
        return object : IncomingFile {
            override val output: OutputStream = out
            override fun commit() {
                out.close()
                if (!part.renameTo(target)) throw IOException("rename")
                // Izvorni datum izmjene datoteke.
                item.modified?.let { target.setLastModified(it) }
                MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), null, null)
                if (item.category == TransferCategory.APPS) rememberApp(item, Uri.fromFile(target))
            }
            override fun abort() {
                try { out.close() } catch (e: Exception) { }
                part.delete()
            }
        }
    }

    private fun createMedia(item: TransferItem): IncomingFile {
        val m = mime(item)
        val isMedia = m.startsWith("image/") || m.startsWith("video/")
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, item.name)
            put(MediaStore.MediaColumns.MIME_TYPE, m)
            put(MediaStore.MediaColumns.RELATIVE_PATH, targetDir(item))
            put(MediaStore.MediaColumns.IS_PENDING, 1)
            if (isMedia) (item.taken ?: item.modified)?.let { put(MediaStore.MediaColumns.DATE_TAKEN, it) }
        }
        val uri: Uri = resolver.insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
            ?: throw IOException("insert")
        val raw = try {
            resolver.openOutputStream(uri, "w") ?: throw IOException("open")
        } catch (e: Exception) {
            resolver.delete(uri, null, null); throw e
        }
        val out = BufferedOutputStream(raw, 1 shl 20)
        return object : IncomingFile {
            override val output: OutputStream = out
            override fun commit() {
                out.close()
                // Fotografija/videozapis bez datuma snimanja: upis izvornog datuma u samu datoteku.
                if (isMedia && item.taken == null) item.modified?.let { embedDate(uri, item.name, it) }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
                item.modified?.let { restoreModified(uri, it) }
                if (item.category == TransferCategory.APPS) rememberApp(item, uri)
            }
            override fun abort() {
                try { out.close() } catch (e: Exception) { }
                try { resolver.delete(uri, null, null) } catch (e: Exception) { }
            }
        }
    }

    /** Upisuje datum u EXIF (JPG/PNG/WEBP) ili MP4/MOV, samo ako datoteka nema vlastiti datum snimanja. */
    private fun embedDate(uri: Uri, name: String, millis: Long) {
        val ext = FileClassifier.extension(name)
        try {
            resolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                when (ext) {
                    in DateWriter.EXIF_EXT -> {
                        val exif = ExifInterface(pfd.fileDescriptor)
                        if (exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL).isNullOrBlank()) {
                            val zdt = java.time.Instant.ofEpochMilli(millis).atZone(java.time.ZoneId.systemDefault())
                            val text = zdt.format(java.time.format.DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss"))
                            val offset = zdt.offset.id.let { if (it == "Z") "+00:00" else it }
                            exif.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, text)
                            exif.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, text)
                            exif.setAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL, offset)
                            exif.saveAttributes()
                        }
                    }
                    in DateWriter.MP4_EXT -> {
                        val io = DateWriter.FdIO(pfd.fileDescriptor)
                        val existing = Mp4Dates.read(io)
                        if (existing == null || existing < MIN_VALID_DATE) Mp4Dates.write(io, millis)
                    }
                }
            }
        } catch (e: Throwable) {
            // Datum je dodatak – datoteka je već ispravno primljena.
        }
    }

    /**
     * Pokušaj vraćanja izvornog datuma izmjene. Aplikacija smije mijenjati datoteke koje je sama stvorila;
     * ako sustav to ne dopusti, ostaje datum primanja (datum snimanja u EXIF-u/videozapisu i dalje vrijedi).
     */
    private fun restoreModified(uri: Uri, millis: Long) {
        try {
            @Suppress("DEPRECATION")
            val path = resolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null
            } ?: return
            val f = File(path)
            if (f.exists() && f.setLastModified(millis)) {
                MediaScannerConnection.scanFile(context, arrayOf(path), null, null)
            }
        } catch (e: Exception) {
        }
    }

    private fun uniqueFile(dir: File, name: String): File {
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        var i = 1
        while (true) {
            val f = File(dir, "$base ($i)$ext")
            if (!f.exists()) return f
            i++
        }
    }

    companion object {
        /** Sigurnosna rezerva slobodnog prostora (200 MB). */
        private const val RESERVE = 200L * 1024 * 1024
        private const val DIRECT_ROOT = "DuoMove/"
        private const val MEDIA_ROOT = "Download/DuoMove/"
        /** 1. 1. 1990. – stariji datum u MP4 smatra se nepostojećim (npr. 0 = 1904.). */
        private const val MIN_VALID_DATE = 631_152_000_000L

        /** Puna putanja mape u koju se spremaju primljene datoteke (za prikaz korisniku). */
        fun receiveRoot(): String {
            val base = Environment.getExternalStorageDirectory()
            val rel = if (StorageAccess.hasAllFilesAccess()) DIRECT_ROOT else MEDIA_ROOT
            return File(base, rel.trimEnd('/')).absolutePath
        }
    }
}
