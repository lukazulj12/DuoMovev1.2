package hr.smartduplicatecleaner.ui.datefix

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.dates.DateFixItem
import hr.smartduplicatecleaner.core.dates.DayMonthOrder
import hr.smartduplicatecleaner.core.dates.IntervalBasis
import hr.smartduplicatecleaner.core.dates.NameDateParser
import hr.smartduplicatecleaner.core.dates.NamePattern
import hr.smartduplicatecleaner.datefix.DateWriter
import hr.smartduplicatecleaner.storage.MediaAccess
import hr.smartduplicatecleaner.storage.StorageAccess
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.FileThumbnail
import hr.smartduplicatecleaner.ui.components.IntervalPicker
import hr.smartduplicatecleaner.ui.components.NoticeCard
import hr.smartduplicatecleaner.ui.components.RadioLine
import hr.smartduplicatecleaner.ui.components.SectionTitle
import hr.smartduplicatecleaner.ui.components.formatDateTime
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset

/** Postavke i pokretanje analize datuma. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateFixScreen(vm: DateFixViewModel, prefs: DisplayPrefs, onResults: () -> Unit) {
    val context = LocalContext.current
    val p by vm.prefs.collectAsState()
    val ui by vm.ui.collectAsState()
    var refresh by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) { refresh++; onPauseOrDispose { } }
    val access = remember(refresh) { StorageAccess.mediaAccess(context) }
    val allFiles = remember(refresh) { StorageAccess.hasAllFilesAccess() }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++; vm.loadFolders() }
    var showFolders by remember { mutableStateOf(false) }
    var showAddPattern by remember { mutableStateOf(false) }
    LaunchedEffect(access) { if (access != MediaAccess.NONE) vm.loadFolders() }

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.datefix_title)) }) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = { vm.analyze(); onResults() },
                    enabled = access != MediaAccess.NONE && !ui.analyzing && (p.includePhotos || p.includeVideos),
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp)
                ) {
                    Icon(Icons.Filled.Search, null)
                    Spacer(Modifier.size(8.dp))
                    Text(stringResource(R.string.datefix_analyze), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            NoticeCard(stringResource(R.string.datefix_intro), warning = false)
            if (access == MediaAccess.NONE) {
                NoticeCard(stringResource(R.string.access_media_none))
                Button(onClick = { permLauncher.launch(StorageAccess.mediaPermissions()) }) { Text(stringResource(R.string.grant_media)) }
            }

            SectionTitle(stringResource(R.string.datefix_types_title))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = p.includePhotos,
                    onClick = { vm.setTypes(!p.includePhotos, p.includeVideos) },
                    label = { Text(stringResource(R.string.tr_cat_photos)) }
                )
                FilterChip(
                    selected = p.includeVideos,
                    onClick = { vm.setTypes(p.includePhotos, !p.includeVideos) },
                    label = { Text(stringResource(R.string.tr_cat_videos)) }
                )
            }

            SectionTitle(stringResource(R.string.folders))
            OutlinedButton(onClick = { showFolders = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.FolderOpen, null)
                Spacer(Modifier.size(8.dp))
                Text(
                    if (p.folders.isEmpty()) stringResource(R.string.datefix_all_folders)
                    else stringResource(R.string.datefix_folders_selected, p.folders.size)
                )
            }

            SectionTitle(stringResource(R.string.date_range_title))
            IntervalPicker(
                enabled = p.intervalEnabled, from = p.from, to = p.to, prefs = prefs,
                onEnabled = { on -> vm.update { it.copy(intervalEnabled = on) } },
                onChange = { f, t -> vm.update { it.copy(from = f, to = t) } }
            )
            if (p.intervalEnabled) {
                Text(stringResource(R.string.datefix_interval_basis), style = MaterialTheme.typography.labelLarge)
                RadioLine(p.basis == IntervalBasis.NAME_DATE, stringResource(R.string.datefix_basis_name)) { vm.update { it.copy(basis = IntervalBasis.NAME_DATE) } }
                RadioLine(p.basis == IntervalBasis.CURRENT_DATE, stringResource(R.string.datefix_basis_current)) { vm.update { it.copy(basis = IntervalBasis.CURRENT_DATE) } }
            }

            SectionTitle(stringResource(R.string.datefix_order_title))
            Text(stringResource(R.string.datefix_order_hint), style = MaterialTheme.typography.bodySmall)
            listOf(
                DayMonthOrder.STANDARD to R.string.datefix_order_standard,
                DayMonthOrder.MONTH_FIRST to R.string.datefix_order_month_first,
                DayMonthOrder.DAY_FIRST to R.string.datefix_order_day_first,
                DayMonthOrder.SKIP_AMBIGUOUS to R.string.datefix_order_skip
            ).forEach { (o, label) -> RadioLine(p.order == o, stringResource(label)) { vm.update { it.copy(order = o) } } }
            SwitchLine(stringResource(R.string.datefix_timestamps), p.timestamps) { on -> vm.update { it.copy(timestamps = on) } }

            SectionTitle(stringResource(R.string.datefix_patterns_title))
            Text(stringResource(R.string.datefix_patterns_hint), style = MaterialTheme.typography.bodySmall)
            p.patterns.forEach { pat ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(pat, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    IconButton(onClick = { vm.update { it.copy(patterns = it.patterns - pat) } }) { Icon(Icons.Filled.Close, stringResource(R.string.remove)) }
                }
            }
            OutlinedButton(onClick = { showAddPattern = true }) {
                Icon(Icons.Filled.Add, null); Spacer(Modifier.size(6.dp)); Text(stringResource(R.string.datefix_add_pattern))
            }

            SectionTitle(stringResource(R.string.datefix_what_title))
            SwitchLine(stringResource(R.string.datefix_write_meta), p.writeMetadata) { on -> vm.update { it.copy(writeMetadata = on) } }
            Text(stringResource(R.string.datefix_write_meta_hint), style = MaterialTheme.typography.bodySmall)
            SwitchLine(stringResource(R.string.datefix_write_modified), p.writeModified && allFiles, enabled = allFiles) { on -> vm.update { it.copy(writeModified = on) } }
            Text(
                stringResource(if (allFiles) R.string.datefix_write_modified_hint else R.string.datefix_write_modified_unavailable),
                style = MaterialTheme.typography.bodySmall
            )
            SwitchLine(stringResource(R.string.datefix_compare_time), p.compareTime) { on -> vm.update { it.copy(compareTime = on) } }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showFolders) {
        FolderDialog(
            folders = ui.folders,
            selected = p.folders,
            onToggle = { dir -> vm.update { s -> s.copy(folders = if (dir in s.folders) s.folders - dir else s.folders + dir) } },
            onClear = { vm.update { it.copy(folders = emptySet()) } },
            onDismiss = { showFolders = false }
        )
    }
    if (showAddPattern) {
        PatternDialog(
            existing = p,
            onAdd = { pat -> vm.update { it.copy(patterns = (it.patterns + pat).distinct()) }; showAddPattern = false },
            onDismiss = { showAddPattern = false }
        )
    }
}

@Composable
private fun SwitchLine(text: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun FolderDialog(
    folders: List<hr.smartduplicatecleaner.datefix.MediaFolder>?,
    selected: Set<String>,
    onToggle: (String) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.datefix_choose_folders)) },
        text = {
            Column {
                Text(stringResource(R.string.datefix_folders_hint), style = MaterialTheme.typography.bodySmall)
                if (folders == null) CircularProgressIndicator(Modifier.padding(16.dp))
                else LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(folders, key = { it.relativeDir }) { f ->
                        Row(Modifier.fillMaxWidth().clickable { onToggle(f.relativeDir) }, verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = f.relativeDir in selected, onCheckedChange = { onToggle(f.relativeDir) })
                            Text(f.relativeDir.ifEmpty { "/" }, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(f.count.toString(), style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onClear) { Text(stringResource(R.string.datefix_all_folders)) } }
    )
}

/** Dodavanje ručnog uzorka s provjerom i probnim nazivom. */
@Composable
private fun PatternDialog(existing: hr.smartduplicatecleaner.data.settings.DateFixPrefs, onAdd: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var sample by remember { mutableStateOf("") }
    val error: NamePattern.Reason? = if (text.isBlank()) null else try { NamePattern.compile(text); null } catch (e: NamePattern.InvalidPatternException) { e.reason }
    val parsed = if (text.isNotBlank() && error == null && sample.isNotBlank())
        NameDateParser(existing.order, listOf(text), detectTimestamps = false).parse(sample) else null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.datefix_add_pattern)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.datefix_pattern_help), style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    label = { Text(stringResource(R.string.datefix_pattern)) },
                    placeholder = { Text("IMG-yyyyMMdd-WA*") },
                    isError = error != null, modifier = Modifier.fillMaxWidth()
                )
                if (error != null) Text(patternError(error), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = sample, onValueChange = { sample = it }, singleLine = true,
                    label = { Text(stringResource(R.string.datefix_sample_name)) },
                    placeholder = { Text("IMG-20261028-WA0014.jpg") }, modifier = Modifier.fillMaxWidth()
                )
                if (sample.isNotBlank() && error == null && text.isNotBlank()) {
                    Text(
                        parsed?.let { stringResource(R.string.datefix_sample_ok, it.date.toString() + (it.time?.let { t -> " $t" } ?: "")) }
                            ?: stringResource(R.string.datefix_sample_no_match),
                        style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank() && error == null, onClick = { onAdd(text.trim()) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
private fun patternError(r: NamePattern.Reason): String = stringResource(
    when (r) {
        NamePattern.Reason.EMPTY -> R.string.pattern_err_empty
        NamePattern.Reason.MISSING_YEAR -> R.string.pattern_err_year
        NamePattern.Reason.MISSING_MONTH -> R.string.pattern_err_month
        NamePattern.Reason.MISSING_DAY -> R.string.pattern_err_day
        NamePattern.Reason.DUPLICATE_TOKEN -> R.string.pattern_err_duplicate
    }
)

/** Rezultati analize: datoteke čiji datum ne odgovara nazivu, odabir i ispravak. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateFixResultsScreen(vm: DateFixViewModel, prefs: DisplayPrefs, onBack: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val p by vm.prefs.collectAsState()
    var confirm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<DateFixItem?>(null) }
    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        vm.onWriteRequestResult(result.resultCode == android.app.Activity.RESULT_OK)
    }
    LaunchedEffect(ui.writeRequest) {
        val req = ui.writeRequest
        if (req != null && vm.claimRequestLaunch()) writeLauncher.launch(IntentSenderRequest.Builder(req).build())
    }
    // Zaslon ostaje upaljen dok traje ispravak.
    val view = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.DisposableEffect(ui.running) {
        view.keepScreenOn = ui.running
        onDispose { view.keepScreenOn = false }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.datefix_results_title)) },
                navigationIcon = { IconButton(onClick = onBack, enabled = !ui.running) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
                    if (ui.running) {
                        LinearProgressIndicator(
                            progress = { if (ui.progressTotal > 0) ui.progressDone.toFloat() / ui.progressTotal else 0f },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(stringResource(R.string.progress_of, ui.progressDone, ui.progressTotal))
                        if (ui.batchCount > 1) Text(stringResource(R.string.datefix_batch, ui.batch, ui.batchCount), style = MaterialTheme.typography.bodySmall)
                    } else {
                        Button(
                            onClick = { confirm = true },
                            enabled = ui.selected.isNotEmpty() && !ui.analyzing,
                            modifier = Modifier.fillMaxWidth().height(56.dp)
                        ) {
                            Icon(Icons.Filled.EditCalendar, null)
                            Spacer(Modifier.size(8.dp))
                            Text(stringResource(R.string.datefix_fix_selected, ui.selected.size))
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (ui.analyzing) {
            Column(Modifier.fillMaxSize().padding(padding), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                CircularProgressIndicator()
                Text(stringResource(R.string.datefix_analyzing), Modifier.padding(16.dp))
            }
            return@Scaffold
        }
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(stringResource(R.string.datefix_summary_fix, ui.toFix.size), fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.datefix_summary_ok, ui.okCount))
                        Text(stringResource(R.string.datefix_summary_no_date, ui.noDateCount))
                        if (ui.outOfIntervalCount > 0) Text(stringResource(R.string.datefix_summary_interval, ui.outOfIntervalCount))
                    }
                }
                if (ui.toFix.isNotEmpty()) Row {
                    TextButton(onClick = { vm.selectAll(true) }) { Text(stringResource(R.string.select_all)) }
                    TextButton(onClick = { vm.selectAll(false) }) { Text(stringResource(R.string.select_none)) }
                }
            }
            items(ui.toFix, key = { it.file.uri }) { item ->
                FixRow(item, vm.target(item), item.file.uri in ui.selected, ui.overrides.containsKey(item.file.uri), prefs,
                    onToggle = { vm.toggle(item.file.uri) }, onEdit = { editing = item })
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(stringResource(R.string.datefix_confirm_title)) },
            text = {
                Column {
                    Text(stringResource(R.string.datefix_confirm_text, ui.selected.size))
                    if (!StorageAccess.hasAllFilesAccess() && ui.selected.size > DateFixViewModel.BATCH) {
                        Text(
                            stringResource(R.string.datefix_batches_hint, (ui.selected.size + DateFixViewModel.BATCH - 1) / DateFixViewModel.BATCH, DateFixViewModel.BATCH),
                            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { confirm = false; vm.fixSelected() }) { Text(stringResource(R.string.datefix_fix_now)) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    editing?.let { item -> EditDateDialog(item, vm.target(item), onDismiss = { editing = null }) { vm.override(item.file.uri, it); editing = null } }
    ui.report?.let { report ->
        val ok = report.count { it.ok }
        val failed = report.filter { !it.ok }
        AlertDialog(
            onDismissRequest = { vm.closeReport() },
            title = { Text(stringResource(R.string.report_title)) },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text(stringResource(R.string.datefix_report_ok, ok), fontWeight = FontWeight.Bold)
                    if (ui.notProcessed > 0) Text(stringResource(R.string.datefix_report_declined, ui.notProcessed), color = MaterialTheme.colorScheme.error)
                    if (failed.isNotEmpty()) {
                        Text(stringResource(R.string.report_failed, failed.size), color = MaterialTheme.colorScheme.error)
                        failed.take(100).forEach { r ->
                            Text(r.file.name + " – " + writeError(r.error), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.closeReport() }) { Text(stringResource(R.string.ok)) } }
        )
    }
}

@Composable
private fun writeError(e: String?): String = when (e) {
    DateWriter.UNSUPPORTED -> stringResource(R.string.datefix_err_unsupported)
    DateWriter.NO_PERMISSION -> stringResource(R.string.datefix_err_permission)
    DateWriter.MTIME_FAILED -> stringResource(R.string.datefix_err_mtime)
    else -> e ?: stringResource(R.string.fail_unknown)
}

@Composable
private fun FixRow(
    item: DateFixItem, target: Long?, selected: Boolean, overridden: Boolean, prefs: DisplayPrefs,
    onToggle: () -> Unit, onEdit: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = selected, onCheckedChange = { onToggle() })
            FileThumbnail(item.file, Modifier.size(56.dp), sizePx = 160)
            Column(Modifier.weight(1f).padding(start = 8.dp)) {
                Text(item.file.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.file.relativeDir, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    stringResource(R.string.datefix_current, item.shownMillis?.let { formatDateTime(it, prefs) } ?: stringResource(R.string.not_available)),
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    stringResource(if (overridden) R.string.datefix_new_manual else R.string.datefix_new, target?.let { formatDateTime(it, prefs) } ?: "?"),
                    style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary
                )
                if (item.nameDate?.ambiguous == true && !overridden) {
                    Text(stringResource(R.string.datefix_ambiguous), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                }
            }
            IconButton(onClick = onEdit) { Icon(Icons.Filled.EditCalendar, stringResource(R.string.datefix_edit_date)) }
        }
    }
}

/** Ručni odabir datuma za jednu datoteku (vrijeme u danu ostaje isto). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditDateDialog(item: DateFixItem, current: Long?, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val zone = ZoneId.systemDefault()
    val base = current ?: System.currentTimeMillis()
    val zdt = Instant.ofEpochMilli(base).atZone(zone)
    val state = rememberDatePickerState(initialSelectedDateMillis = zdt.toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
    val time: LocalTime = zdt.toLocalTime()
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                state.selectedDateMillis?.let { utc ->
                    val day = Instant.ofEpochMilli(utc).atZone(ZoneOffset.UTC).toLocalDate()
                    onPick(day.atTime(time).atZone(zone).toInstant().toEpochMilli())
                } ?: onDismiss()
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    ) {
        Column {
            Text(item.file.name, Modifier.padding(horizontal = 24.dp, vertical = 8.dp), style = MaterialTheme.typography.bodySmall)
            HorizontalDivider()
            DatePicker(state = state)
        }
    }
}
