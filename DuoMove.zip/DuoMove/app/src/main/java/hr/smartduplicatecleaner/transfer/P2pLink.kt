package hr.smartduplicatecleaner.transfer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pGroup
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Looper
import androidx.core.content.ContextCompat
import hr.smartduplicatecleaner.core.transfer.PairingCode
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.net.Inet4Address
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class P2pException(val code: Int) : Exception("Wi-Fi Direct: $code")

/**
 * Izravna Wi-Fi veza (Wi-Fi Direct) bez rutera i bez interneta.
 * Primatelj (novi mobitel) stvara mrežu s nazivom [PairingCode.NETWORK_NAME] i lozinkom izvedenom iz koda,
 * po mogućnosti u pojasu 5 GHz (brže). Pošiljatelj se pridružuje istim nazivom i lozinkom – bez traženja i
 * bez dodatnog potvrđivanja. IP adresa primatelja (vlasnika grupe) je 192.168.49.1.
 */
class P2pLink(private val context: Context) {
    private val manager: WifiP2pManager? = context.getSystemService(WifiP2pManager::class.java)
    private var channel: WifiP2pManager.Channel? = null

    val isSupported: Boolean
        get() = manager != null && context.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)

    private fun ch(): WifiP2pManager.Channel =
        channel ?: manager!!.initialize(context, Looper.getMainLooper(), null).also { channel = it }

    private fun config(code: String, band: Int): WifiP2pConfig = WifiP2pConfig.Builder()
        .setNetworkName(PairingCode.NETWORK_NAME)
        .setPassphrase(PairingCode.passphrase(code))
        .setGroupOperatingBand(band)
        .enablePersistentMode(false)
        .build()

    private suspend fun action(block: (WifiP2pManager.ActionListener) -> Unit) =
        suspendCancellableCoroutine<Unit> { cont ->
            block(object : WifiP2pManager.ActionListener {
                override fun onSuccess() { if (cont.isActive) cont.resume(Unit) }
                override fun onFailure(reason: Int) { if (cont.isActive) cont.resumeWithException(P2pException(reason)) }
            })
        }

    @SuppressLint("MissingPermission")
    private suspend fun groupInfo(): WifiP2pGroup? = suspendCancellableCoroutine { cont ->
        manager!!.requestGroupInfo(ch()) { g -> if (cont.isActive) cont.resume(g) }
    }

    private suspend fun connectionInfo(): WifiP2pInfo? = suspendCancellableCoroutine { cont ->
        manager!!.requestConnectionInfo(ch()) { info -> if (cont.isActive) cont.resume(info) }
    }

    private suspend fun removeGroupQuietly() {
        try { action { manager!!.removeGroup(ch(), it) } } catch (e: Exception) { }
    }

    /** Primatelj: stvara Wi-Fi Direct mrežu (5 GHz ako uređaj podržava, inače automatski). */
    @SuppressLint("MissingPermission")
    suspend fun createGroup(code: String) {
        if (!isSupported) throw P2pException(WifiP2pManager.P2P_UNSUPPORTED)
        removeGroupQuietly()
        try {
            action { manager!!.createGroup(ch(), config(code, WifiP2pConfig.GROUP_OWNER_BAND_5GHZ), it) }
        } catch (e: P2pException) {
            removeGroupQuietly()
            action { manager!!.createGroup(ch(), config(code, WifiP2pConfig.GROUP_OWNER_BAND_AUTO), it) }
        }
        withTimeout(20_000) {
            while (groupInfo() == null) delay(300)
        }
    }

    /** Pošiljatelj: pridružuje se mreži primatelja; vraća IP adresu primatelja. */
    @SuppressLint("MissingPermission")
    suspend fun join(code: String): String {
        if (!isSupported) throw P2pException(WifiP2pManager.P2P_UNSUPPORTED)
        removeGroupQuietly()
        action { manager!!.connect(ch(), config(code, WifiP2pConfig.GROUP_OWNER_BAND_AUTO), it) }
        return withTimeout(45_000) {
            var address: String? = null
            while (address == null) {
                val info = connectionInfo()
                if (info != null && info.groupFormed && !info.isGroupOwner) address = info.groupOwnerAddress?.hostAddress
                if (address == null) delay(500)
            }
            address!!
        }
    }

    fun close() {
        val m = manager ?: return
        val c = channel ?: return
        try { m.removeGroup(c, null) } catch (e: Exception) { }
        try { c.close() } catch (e: Exception) { }
        channel = null
    }

    companion object {
        /** Dopuštenja potrebna za Wi-Fi Direct. */
        fun permissions(): Array<String> =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)

        fun hasPermissions(context: Context): Boolean = permissions().all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }

        fun isWifiEnabled(context: Context): Boolean =
            context.applicationContext.getSystemService(WifiManager::class.java)?.isWifiEnabled == true

        /** Na Androidu 12 i starijem Wi-Fi Direct zahtijeva uključenu lokaciju. */
        fun isLocationOk(context: Context): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) return true
            return context.getSystemService(LocationManager::class.java)?.isLocationEnabled == true
        }

        /** IPv4 adresa u trenutačnoj Wi-Fi mreži (način "ista mreža"). */
        fun localIpv4(context: Context): String? {
            val cm = context.getSystemService(ConnectivityManager::class.java) ?: return null
            val lp = cm.getLinkProperties(cm.activeNetwork) ?: return null
            return lp.linkAddresses.map { it.address }.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }?.hostAddress
        }
    }
}
