package hr.smartduplicatecleaner.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.format.Formatters
import hr.smartduplicatecleaner.core.model.FolderPriority
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.storage.listMediaFolders
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.currentLocale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

/**
 * Uređivanje prioriteta mapa: do 3 povlaštene mape (prva ima najveću prednost pri zadržavanju)
 * i do 3 podređene mape (iz prve se duplikati brišu najprije).
 */
@Composable
fun FolderPriorityEditor(rules: KeepRules, onChange: (KeepRules) -> Unit) {
    SwitchRow(stringResource(R.string.use_folder_priority), rules.useFolderPriority) {
        onChange(rules.copy(useFolderPriority = it))
    }
    Text(stringResource(R.string.folder_priority_hint), style = MaterialTheme.typography.bodySmall)

    FolderList(
        title = stringResource(R.string.preferred_folders),
        hint = stringResource(R.string.preferred_folders_hint),
        folders = rules.preferredFolders,
        exclude = rules.demotedFolders,
        enabled = rules.useFolderPriority,
        onChange = { onChange(rules.copy(preferredFolders = it)) }
    )
    HorizontalDivider(Modifier.padding(vertical = 8.dp))
    FolderList(
        title = stringResource(R.string.demoted_folders),
        hint = stringResource(R.string.demoted_folders_hint),
        folders = rules.demotedFolders,
        exclude = rules.preferredFolders,
        enabled = rules.useFolderPriority,
        onChange = { onChange(rules.copy(demotedFolders = it)) }
    )
}

@Composable
private fun FolderList(
    title: String,
    hint: String,
    folders: List<String>,
    exclude: List<String>,
    enabled: Boolean,
    onChange: (List<String>) -> Unit
) {
    var picking by remember { mutableStateOf(false) }
    Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
    Text(hint, style = MaterialTheme.typography.bodySmall)
    folders.forEachIndexed { i, f ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${i + 1}.", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(end = 6.dp))
            Text(f, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            IconButton(onClick = { onChange(folders.toMutableList().apply { add(i - 1, removeAt(i)) }) }, enabled = enabled && i > 0) {
                Icon(Icons.Filled.KeyboardArrowUp, stringResource(R.string.move_up))
            }
            IconButton(onClick = { onChange(folders.toMutableList().apply { add(i + 1, removeAt(i)) }) }, enabled = enabled && i < folders.size - 1) {
                Icon(Icons.Filled.KeyboardArrowDown, stringResource(R.string.move_down))
            }
            IconButton(onClick = { onChange(folders.filterIndexed { j, _ -> j != i }) }, enabled = enabled) {
                Icon(Icons.Filled.Close, stringResource(R.string.remove))
            }
        }
    }
    if (folders.size < FolderPriority.MAX) {
        OutlinedButton(onClick = { picking = true }, enabled = enabled, modifier = Modifier.padding(top = 4.dp)) {
            Icon(Icons.Filled.Add, null)
            Text(stringResource(R.string.add_folder), modifier = Modifier.padding(start = 6.dp))
        }
    }
    if (picking) {
        FolderPickDialog(
            taken = (folders + exclude).map { FolderPriority.normalize(it) }.toSet(),
            onDismiss = { picking = false },
            onPick = { picked ->
                picking = false
                if (folders.size < FolderPriority.MAX) onChange(folders + picked)
            }
        )
    }
}

/** Odabir mape: česte mape, mape s medijima na uređaju ili ručni unos putanje. */
@Composable
private fun FolderPickDialog(taken: Set<String>, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val context = LocalContext.current
    var deviceFolders by remember { mutableStateOf<List<String>>(emptyList()) }
    var manual by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { deviceFolders = withContext(Dispatchers.IO) { listMediaFolders(context) } }
    val options = (FolderPriority.SUGGESTIONS + deviceFolders)
        .distinctBy { FolderPriority.normalize(it) }
        .filter { FolderPriority.normalize(it) !in taken }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.choose_folder)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = manual,
                    onValueChange = { manual = it },
                    label = { Text(stringResource(R.string.folder_path_manual)) },
                    placeholder = { Text("DCIM/Camera/") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(options, key = { it }) { f ->
                        Text(
                            f,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.fillMaxWidth().clickable { onPick(f) }.padding(vertical = 10.dp)
                        )
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = {
            val normalized = FolderPriority.normalize(manual)
            TextButton(
                enabled = normalized.isNotEmpty() && normalized !in taken,
                onClick = { onPick(manual.trim().trim('/') + "/") }
            ) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

/**
 * Vremenski interval nastanka datoteka koje se skeniraju (od – do, uključivo).
 * Datum nastanka = datum snimanja ako postoji, inače datum posljednje izmjene.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateRangeSection(
    from: Long?,
    to: Long?,
    documentsOnly: Boolean,
    enabled: Boolean,
    prefs: DisplayPrefs,
    onChange: (from: Long?, to: Long?) -> Unit,
    onDocumentsOnly: (Boolean) -> Unit,
    onEnabled: (Boolean) -> Unit
) {
    var editing by remember { mutableStateOf<Boolean?>(null) } // true = od, false = do
    val zone = ZoneId.systemDefault()
    val locale = currentLocale()
    val noLimit = stringResource(R.string.no_limit)
    fun label(millis: Long?): String =
        millis?.let { Formatters.date(it, prefs.europeanDates, locale, zone) } ?: noLimit

    Text(stringResource(R.string.date_range_title), style = MaterialTheme.typography.titleSmall)
    // Isključeno = skeniraju se datoteke iz svih razdoblja; upisani datumi ostaju sačuvani.
    RadioRow(!enabled, stringResource(R.string.date_range_all_times)) { onEnabled(false) }
    RadioRow(enabled, stringResource(R.string.date_range_only_interval)) { onEnabled(true) }
    if (!enabled) return
    Text(stringResource(R.string.date_range_hint), style = MaterialTheme.typography.bodySmall)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { editing = true }, modifier = Modifier.weight(1f)) {
            Text(stringResource(R.string.date_from) + ": " + label(from), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        OutlinedButton(onClick = { editing = false }, modifier = Modifier.weight(1f)) {
            Text(stringResource(R.string.date_to) + ": " + label(to), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
    if (from != null || to != null) {
        TextButton(onClick = { onChange(null, null) }) { Text(stringResource(R.string.date_range_clear)) }
        if (from != null && to != null && from > to) {
            Text(stringResource(R.string.date_range_invalid), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
    RadioRow(documentsOnly, stringResource(R.string.date_range_documents_only)) { onDocumentsOnly(true) }
    RadioRow(!documentsOnly, stringResource(R.string.date_range_all_types)) { onDocumentsOnly(false) }

    val isFrom = editing ?: return
    // DatePicker radi u UTC ponoći; pretvaramo u početak/kraj dana u lokalnoj zoni.
    val initial = (if (isFrom) from else to)?.let {
        Instant.ofEpochMilli(it).atZone(zone).toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    }
    val state = rememberDatePickerState(initialSelectedDateMillis = initial)
    DatePickerDialog(
        onDismissRequest = { editing = null },
        confirmButton = {
            TextButton(onClick = {
                val utc = state.selectedDateMillis
                if (utc != null) {
                    val day: LocalDate = Instant.ofEpochMilli(utc).atZone(ZoneOffset.UTC).toLocalDate()
                    if (isFrom) onChange(day.atStartOfDay(zone).toInstant().toEpochMilli(), to)
                    else onChange(from, day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() - 1)
                }
                editing = null
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = { editing = null }) { Text(stringResource(R.string.cancel)) } }
    ) {
        DatePicker(state = state)
    }
}
