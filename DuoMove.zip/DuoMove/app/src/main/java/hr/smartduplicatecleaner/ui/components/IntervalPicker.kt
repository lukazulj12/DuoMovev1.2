package hr.smartduplicatecleaner.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.format.Formatters
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

/** Redak s radio gumbom (zajednički za sve zaslone). */
@Composable
fun RadioLine(selected: Boolean, text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick).padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick, enabled = enabled)
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

/**
 * Vremenski interval: "Sva vremena" ili "Samo odabrani interval" s datumima Od – Do (uključivo, cijeli dani).
 * Kad je interval isključen, datumi ostaju sačuvani za sljedeći put.
 */
@Composable
fun IntervalPicker(
    enabled: Boolean,
    from: Long?,
    to: Long?,
    prefs: DisplayPrefs,
    onEnabled: (Boolean) -> Unit,
    onChange: (from: Long?, to: Long?) -> Unit
) {
    RadioLine(!enabled, stringResource(R.string.date_range_all_times)) { onEnabled(false) }
    RadioLine(enabled, stringResource(R.string.date_range_only_interval)) { onEnabled(true) }
    if (enabled) DateBounds(from, to, prefs, onChange)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateBounds(from: Long?, to: Long?, prefs: DisplayPrefs, onChange: (from: Long?, to: Long?) -> Unit) {
    var editing by remember { mutableStateOf<Boolean?>(null) } // true = od, false = do
    val zone = ZoneId.systemDefault()
    val locale = currentLocale()
    val noLimit = stringResource(R.string.no_limit)
    fun label(millis: Long?): String = millis?.let { Formatters.date(it, prefs.europeanDates, locale, zone) } ?: noLimit

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { editing = true }, modifier = Modifier.weight(1f)) {
            Text(stringResource(R.string.date_from) + ": " + label(from), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        OutlinedButton(onClick = { editing = false }, modifier = Modifier.weight(1f)) {
            Text(stringResource(R.string.date_to) + ": " + label(to), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
    if (from != null && to != null && from > to) {
        Text(stringResource(R.string.date_range_invalid), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
    if (from != null || to != null) {
        TextButton(onClick = { onChange(null, null) }) { Text(stringResource(R.string.date_range_clear)) }
    }

    val isFrom = editing ?: return
    val initial = (if (isFrom) from else to)?.let {
        Instant.ofEpochMilli(it).atZone(zone).toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    }
    val state = rememberDatePickerState(initialSelectedDateMillis = initial)
    DatePickerDialog(
        onDismissRequest = { editing = null },
        confirmButton = {
            TextButton(onClick = {
                val utc = state.selectedDateMillis
                if (utc != null) {
                    val day: LocalDate = Instant.ofEpochMilli(utc).atZone(ZoneOffset.UTC).toLocalDate()
                    if (isFrom) onChange(day.atStartOfDay(zone).toInstant().toEpochMilli(), to)
                    else onChange(from, day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() - 1)
                }
                editing = null
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = { editing = null }) { Text(stringResource(R.string.cancel)) } }
    ) {
        DatePicker(state = state)
    }
}
