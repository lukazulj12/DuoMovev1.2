package hr.smartduplicatecleaner.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.data.settings.TransferPrefs
import hr.smartduplicatecleaner.ui.datefix.DateFixResultsScreen
import hr.smartduplicatecleaner.ui.datefix.DateFixScreen
import hr.smartduplicatecleaner.ui.datefix.DateFixViewModel
import hr.smartduplicatecleaner.ui.transfer.TransferScreen
import hr.smartduplicatecleaner.ui.transfer.TransferViewModel
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import hr.smartduplicatecleaner.BuildConfig
import hr.smartduplicatecleaner.scan.ScanState
import hr.smartduplicatecleaner.ui.components.DonateBanner
import kotlinx.coroutines.delay
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import hr.smartduplicatecleaner.AppContainer
import hr.smartduplicatecleaner.data.settings.AppSettings
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.delete.DeletionReportScreen
import hr.smartduplicatecleaner.ui.delete.DeletionReviewScreen
import hr.smartduplicatecleaner.ui.home.HomeScreen
import hr.smartduplicatecleaner.ui.recovery.RecoveryScreen
import hr.smartduplicatecleaner.ui.recovery.RecoveryViewModel
import hr.smartduplicatecleaner.ui.results.CompareScreen
import hr.smartduplicatecleaner.ui.results.GroupDetailScreen
import hr.smartduplicatecleaner.ui.results.ResultsScreen
import hr.smartduplicatecleaner.ui.results.ReviewViewModel
import hr.smartduplicatecleaner.ui.settings.FoldersScreen
import hr.smartduplicatecleaner.ui.settings.SettingsScreen

/** Navigacija između zaslona. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppNavHost(container: AppContainer) {
    val nav = rememberNavController()
    // Jedan ViewModel za pregled i brisanje, vezan uz aktivnost (dijele ga svi zasloni pregleda).
    val review: ReviewViewModel = viewModel(factory = viewModelFactory { initializer { ReviewViewModel(container) } })
    val settings by container.settings.settings.collectAsState(initial = AppSettings())
    val summary by container.results.summary.collectAsState(initial = null)
    val prefs = DisplayPrefs(settings.sizeUnit, settings.europeanDates)
    LaunchedEffect(summary?.finishedAt) { review.ensureFresh(summary?.finishedAt) }
    val scanState by container.scanManager.state.collectAsState()
    val dateFix: DateFixViewModel = viewModel(factory = viewModelFactory { initializer { DateFixViewModel(container) } })
    val transfer: TransferViewModel = viewModel(factory = viewModelFactory { initializer { TransferViewModel(container) } })
    val transferState by container.transferManager.state.collectAsState()
    val transferPrefs by container.features.transfer.collectAsState(initial = TransferPrefs())

    // Drži zaslon upaljenim dok traje skeniranje ili prijenos (ako je uključeno u postavkama).
    val view = LocalView.current
    val keepOn = (settings.keepScreenOn && scanState is ScanState.Running) ||
        (transferPrefs.keepScreenOn && transferState.isBusy)
    DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }

    // Banner za donaciju nakon završenog skeniranja – jednom po skeniranju, ne prekida ništa.
    var bannerShownFor by rememberSaveable { mutableLongStateOf(0L) }
    var bannerVisible by remember { mutableStateOf(false) }
    val finished = scanState as? ScanState.Finished
    LaunchedEffect(finished?.finishedAt) {
        if (BuildConfig.SHOW_DONATE && finished != null && finished.finishedAt != bannerShownFor) {
            bannerShownFor = finished.finishedAt
            bannerVisible = true
        }
    }
    LaunchedEffect(bannerVisible) {
        if (bannerVisible) {
            delay(12_000)
            bannerVisible = false
        }
    }

    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            // Donja traka s tri dijela aplikacije – vidljiva na glavnim zaslonima.
            if (route in TOP_LEVEL) {
                NavigationBar {
                    TOP_LEVEL_ITEMS.forEach { (r, icon, label) ->
                        NavigationBarItem(
                            selected = route == r,
                            onClick = {
                                nav.navigate(r) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(icon, null) },
                            label = { Text(stringResource(label)) }
                        )
                    }
                }
            }
        }
    ) { inner ->
    Box(Modifier.fillMaxSize().padding(inner).consumeWindowInsets(inner)) {
    NavHost(navController = nav, startDestination = "home") {
        composable("transfer") {
            TransferScreen(vm = transfer, prefs = prefs)
        }
        composable("datefix") {
            DateFixScreen(vm = dateFix, prefs = prefs, onResults = { nav.navigate("datefix/results") })
        }
        composable("datefix/results") {
            DateFixResultsScreen(vm = dateFix, prefs = prefs, onBack = { nav.popBackStack() })
        }
        composable("home") {
            HomeScreen(
                container = container,
                onReview = { nav.navigate("results") },
                onSettings = { nav.navigate("settings") },
                onFolders = { nav.navigate("folders") },
                onRecovery = { nav.navigate("recovery") }
            )
        }
        composable("results") {
            ResultsScreen(
                vm = review,
                prefs = prefs,
                onBack = { nav.popBackStack() },
                onOpenGroup = { id -> nav.navigate("group/$id") },
                onReviewDeletion = { nav.navigate("deleteReview") }
            )
        }
        composable("group/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            val id = entry.arguments?.getString("id").orEmpty()
            GroupDetailScreen(
                vm = review,
                groupId = id,
                prefs = prefs,
                onBack = { nav.popBackStack() },
                // Prethodna/sljedeća grupa zamjenjuje trenutačnu, pa "natrag" vodi na popis.
                onOpenGroup = { next -> nav.navigate("group/$next") { popUpTo("results") } },
                onCompare = { gid, index -> nav.navigate("compare/$gid/$index") }
            )
        }
        composable(
            "compare/{id}/{index}",
            arguments = listOf(
                navArgument("id") { type = NavType.StringType },
                navArgument("index") { type = NavType.IntType }
            )
        ) { entry ->
            CompareScreen(
                vm = review,
                groupId = entry.arguments?.getString("id").orEmpty(),
                startIndex = entry.arguments?.getInt("index") ?: 0,
                prefs = prefs,
                onBack = { nav.popBackStack() }
            )
        }
        composable("deleteReview") {
            DeletionReviewScreen(
                vm = review,
                prefs = prefs,
                mode = settings.deletionMode,
                onBack = { nav.popBackStack() },
                onFinished = { nav.navigate("deleteReport") { popUpTo("results") } }
            )
        }
        composable("deleteReport") {
            DeletionReportScreen(vm = review, prefs = prefs, onDone = { nav.popBackStack("results", inclusive = false) })
        }
        composable("settings") {
            SettingsScreen(repo = container.settings, onBack = { nav.popBackStack() }, onFolders = { nav.navigate("folders") })
        }
        composable("folders") {
            FoldersScreen(repo = container.settings, onBack = { nav.popBackStack() })
        }
        composable("recovery") {
            val vm: RecoveryViewModel = viewModel(factory = viewModelFactory { initializer { RecoveryViewModel(container) } })
            RecoveryScreen(vm = vm, prefs = prefs, onBack = { nav.popBackStack() })
        }
    }
    AnimatedVisibility(
        visible = bannerVisible,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut(),
        modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        DonateBanner(onClose = { bannerVisible = false })
    }
    }
    }
}

private val TOP_LEVEL = setOf("home", "transfer", "datefix")

private val TOP_LEVEL_ITEMS: List<Triple<String, ImageVector, Int>> = listOf(
    Triple("home", Icons.Filled.CleaningServices, R.string.nav_cleaner),
    Triple("transfer", Icons.Filled.SwapHoriz, R.string.nav_transfer),
    Triple("datefix", Icons.Filled.EditCalendar, R.string.nav_datefix)
)
