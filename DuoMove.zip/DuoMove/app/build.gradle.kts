import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// Podaci za potpisivanje: iz datoteke keystore.properties (lokalno) ili iz varijabli okruženja (GitHub Actions).
// Ključ se NIKAD ne sprema u repozitorij.
val keystoreProps = Properties().apply {
    rootProject.file("keystore.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) }
}
fun signingValue(key: String, env: String): String? =
    keystoreProps.getProperty(key) ?: System.getenv(env)?.takeIf { it.isNotBlank() }

android {
    // Interni paket koda (ne vidi se korisniku).
    namespace = "hr.smartduplicatecleaner"
    compileSdk = 36

    defaultConfig {
        // Jedinstveni ID aplikacije na Google Playu – NE MOŽE se promijeniti nakon prve objave.
        applicationId = "hr.zulj.duomove"
        // Android 11+: jedinstvena pravila pohrane (scoped storage), MediaStore.createDeleteRequest/createTrashRequest.
        minSdk = 30
        // Google Play od 31. 8. 2026. traži targetSdk 36 (Android 16) za nove aplikacije i ažuriranja.
        targetSdk = 36
        // Pri svakom novom uploadu na Google Play povećajte versionCode (2, 3, 4…) i po želji versionName.
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        // Samo hrvatski i engleski – manji APK.
        resourceConfigurations += listOf("en", "hr")
        // Poveznica za donaciju ("Počasti developera kavom").
        buildConfigField("String", "DONATE_URL", "\"https://paypal.me/lfzulj\"")
    }

    // Dvije inačice iz istog koda:
    //  - full: za instalaciju APK-a izravno na mobitel (svi dopuštenja, gumb za donaciju)
    //  - play: za Google Play (bez dopuštenja "Pristup svim datotekama", bez vanjske poveznice za plaćanje)
    flavorDimensions += "distribution"
    productFlavors {
        create("full") {
            dimension = "distribution"
            buildConfigField("boolean", "ALLOW_ALL_FILES", "true")
            buildConfigField("boolean", "SHOW_DONATE", "true")
            buildConfigField("boolean", "ALLOW_INSTALL", "true")
        }
        create("play") {
            dimension = "distribution"
            buildConfigField("boolean", "ALLOW_ALL_FILES", "false")
            // Pravila Google Playa: donacije developeru preko vanjske poveznice (PayPal) mogu dovesti do odbijanja.
            // Promijenite u "true" samo ako svjesno prihvaćate taj rizik.
            buildConfigField("boolean", "SHOW_DONATE", "false")
            // Google Play dopušta REQUEST_INSTALL_PACKAGES samo aplikacijama kojima je to osnovna namjena.
            buildConfigField("boolean", "ALLOW_INSTALL", "false")
        }
    }

    signingConfigs {
        create("upload") {
            val path = signingValue("storeFile", "SIGNING_STORE_FILE")
            if (path != null) {
                storeFile = file(path)
                storePassword = signingValue("storePassword", "SIGNING_STORE_PASSWORD")
                keyAlias = signingValue("keyAlias", "SIGNING_KEY_ALIAS")
                keyPassword = signingValue("keyPassword", "SIGNING_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // S ključem za upload (Google Play) ako je zadan, inače debug ključem (samo za vlastiti mobitel).
            val upload = signingConfigs.getByName("upload")
            signingConfig = if (upload.storeFile != null) upload else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(project(":core"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.service)
    implementation(libs.androidx.navigation.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.exifinterface)
    implementation(libs.coil.compose)
    implementation(libs.coil.video)
    implementation(libs.kotlinx.coroutines.android)

    testImplementation(libs.junit)

    androidTestImplementation(libs.androidx.test.junit)
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
