# DuoMove

Android aplikacija s tri dijela, koje biraš na **donjoj traci**:

1. **Duplikati** – pronalaženje i sigurno uklanjanje dupliciranih datoteka
2. **Prijenos** – slanje/primanje datoteka između dva mobitela izravnom Wi-Fi vezom
3. **Datumi** – ispravak datuma fotografija i videozapisa prema datumu u nazivu

Sve radi lokalno – bez registracije, oglasa i slanja podataka na internet.

> **Stanje provjere:** jezgra (`core`) je kompajlirana i testirana – 57 testova prolazi, uključujući stvarni prijenos
> preko TCP veza (vidi `TEST_RESULTS.md`). Android dio (`app`) gradi se na GitHubu; u okruženju u kojem je pisan Android SDK nije bio
> dostupan, pa ga nije bilo moguće kompajlirati. Ako izgradnja javi pogrešku, pošaljite zapis pogreške.

## Sadržaj
1. Izgradnja APK-a na GitHubu
2. Inačice `full` i `play`
3. Instalacija na mobitel
4. Duplikati
5. Prijenos između mobitela
6. Ispravak datuma po nazivu
7. **Objava na Google Play – korak po korak**
8. Dopuštenja
9. Arhitektura
10. Poznata ograničenja

---

## 1. Izgradnja APK-a na GitHubu (bez Android Studija)

1. GitHub → repozitorij → **Add file → Upload files** → povucite sadržaj raspakirane mape (ili sam zip) → **Commit changes**.
   Prije toga obrišite stari zip iz repozitorija.
2. Workflow `.github/workflows/build-apk.yml` pokreće se sam. Ako u repozitoriju postoji i stari `main.yml`, zamijenite njegov
   sadržaj sadržajem `build-apk.yml` (ili ga obrišite).
3. **Actions** → zadnji prolaz → zelena kvačica → pod **Artifacts** preuzmite **DuoMove-apk** (`app-full-debug.apk`).

Android Studio (alternativa): *File → Open* → *Build → Build APK(s)*, ili `./gradlew :app:assembleFullDebug`.

## 2. Inačice

| | **full** (APK na vlastiti mobitel) | **play** (Google Play) |
|---|---|---|
| Duplikati, prijenos, ispravak datuma | ✅ | ✅ |
| „Pristup svim datotekama” (cijela pohrana, točne mape pri prijenosu, datum izmjene datoteke) | ✅ neobavezno | ❌ |
| Instalacija primljenih aplikacija iz DuoMovea | ✅ | ❌ (APK-ovi se spremaju u Download/DuoMove/Apps) |
| Gumb i banner „Počasti developera kavom” | ✅ | ❌ (vidi 7.11) |

## 3. Instalacija na mobitel
Kopirajte APK na mobitel, otvorite ga i dopustite „Instaliraj nepoznate aplikacije”. Potreban je **Android 11 ili noviji**.
ID aplikacije je novi (`hr.zulj.duomove`), pa se DuoMove instalira kao nova aplikacija – staru „Duplicate Cleaner” možete deinstalirati.

## 4. Duplikati
Kao i dosad: skeniranje, grupe (identične / ista fotografija / slične / isti naziv), pravila odabira (prioritet mapa → datum →
veličina → rezolucija), vremenski interval, rad u pozadini, pregled, potvrda, izvještaj i oporavak.

## 5. Prijenos između mobitela

**Postupak**
1. Na **oba** mobitela otvorite DuoMove → **Prijenos** i odaberite istu vrstu veze (zadano: *Izravna Wi-Fi veza*).
2. **Novi mobitel** → **Primi**. Prikazat će se kod, npr. `K7QM-4XPA`.
3. **Stari mobitel** → **Pošalji** → označite vrste (fotografije, videozapisi, audiozapisi, dokumenti, ZIP/RAR/7Z, APK datoteke,
   aplikacije, ostalo) → po želji vremenski interval → **Pronađi datoteke** → odznačite mape koje ne želite → upišite kod → **Pošalji**.
4. Napredak, brzina i preostalo vrijeme prikazuju se na oba mobitela; na kraju izvještaj.

**Brzina:** izravna Wi-Fi veza (Wi-Fi Direct) u pojasu 5 GHz kad oba mobitela to podržavaju, 4 paralelne TCP veze,
međuspremnici od 1–4 MB i najveće datoteke prve. Stvarna brzina ovisi o mobitelima (obično 20–60 MB/s); držite mobitele blizu.

**Zaslon i rad u pozadini:** na oba mobitela u Prijenosu postoje opcije *Nastavi u pozadini* (usluga s obaviješću, wake lock i
Wi-Fi lock visokih performansi) i *Drži zaslon upaljenim*. Ako proizvođač i dalje gasi aplikaciju: Postavke → Aplikacije → DuoMove →
Baterija → Bez ograničenja.

**Sigurnost:** mreža je zaštićena WPA2 lozinkom izvedenom iz koda; DuoMove dodatno provjerava kod (HMAC-SHA256, kod se ne šalje mrežom).
Zaštita od „../” putanja: datoteke se uvijek spremaju unutar dopuštenih mapa.

**Kamo se spremaju datoteke:** u mapu **DuoMove**, s posebnom podmapom za svaku vrstu:
`DuoMove/Fotografije`, `Videozapisi`, `Audiozapisi`, `Dokumenti`, `Arhive`, `APK`, `Aplikacije`, `Ostalo`
(nazivi prema jeziku aplikacije). Točna putanja prikazana je na zaslonu Prijenos (prije, tijekom i nakon primanja):
- uz „Pristup svim datotekama” (full): `/storage/emulated/0/DuoMove`
- inače: `/storage/emulated/0/Download/DuoMove` – Androidova pravila dopuštaju aplikacijama spremanje svih vrsta datoteka samo u mapu Download.
Opcija *Zadrži nazive izvornih mapa* dodaje podmapu izvorne mape (npr. `DuoMove/Fotografije/Camera`). Datoteke iste veličine i naziva koje
već postoje mogu se preskočiti.

**Izvorni datumi:** zadržava se datum izmjene datoteke (uvijek uz pristup svim datotekama, inače kad Android dopusti) i datum snimanja.
Fotografijama (JPG/PNG/WEBP) i videozapisima (MP4/MOV/3GP) koji nemaju vlastiti datum snimanja (npr. WhatsApp) izvorni datum
upisuje se u datoteku, pa ih galerija na novom mobitelu prikazuje pod pravim datumom.

**Aplikacije:** šalju se APK datoteke instaliranih aplikacija (i dijelovi „split APK”). Podaci aplikacija i prijave ne mogu se prenijeti
(Androidova zaštita). U inačici full primljene aplikacije instalirate gumbom *Instaliraj* (Android traži potvrdu za svaku).

**Rezervna opcija – ista Wi-Fi mreža:** ako jedan mobitel ne podržava Wi-Fi Direct, spojite oba na isti Wi-Fi, odaberite tu opciju;
primatelj prikazuje kod i adresu (npr. 192.168.1.23), pošiljatelj upisuje oboje.

## 6. Ispravak datuma po nazivu

Fotografije i videozapisi kopirani na novi mobitel često dobiju datum kopiranja, pa se u galeriji pojave pod „danas”.
DuoMove uspoređuje datum datoteke s datumom u nazivu i ispravlja ga.

1. **Datumi** → odaberite **fotografije, videozapise ili oboje**, po želji **mape** (zadano sve) i **vremenski interval** (primjenjuje se na datum iz naziva ili na trenutačni datum).
2. **Analiziraj** → popis datoteka čiji datum ne odgovara nazivu: trenutačni datum, novi datum, sličica, oznaka za odabir.
   Datoteke bez datuma u nazivu se **preskaču** (navedeno je koliko ih je). Datum pojedine datoteke možete ručno promijeniti (ikona kalendara).
3. **Ispravi odabrane** → potvrda → izvještaj. Obrada ide u serijama od 400 datoteka (i za nekoliko tisuća datoteka), zaslon ostaje upaljen.
   Bez pristupa svim datotekama Android traži odobrenje izmjene za svaku seriju; uz pristup svim datotekama (APK inačica) ne traži.

**Prepoznati oblici** (primjeri): `IMG-20261028-WA0014.jpg`, `VID_20250705_105923_016.mp4`, `IMG_20230115_120000.jpg`,
`PXL_20241231_235959123.jpg`, `Screenshot_2025-07-05-10-59-23.png`, `scan_15-01-2023.pdf`, `15.01.2023.jpg`, `FB_IMG_1700000000000.jpg` (Unix vrijeme).
Prihvaćaju se samo stvarni datumi od 1990. do danas.

**DDMM ili MMDD:** ako je moguće samo jedno tumačenje (npr. `28102026` – nema 28. mjeseca), koristi se ono. Kad su moguća oba
(npr. `05072025`), odlučuje postavka: *Uobičajeno* (GGGGMMDD i DDMMGGGG), *Mjesec prije dana*, *Dan prije mjeseca* ili *Preskoči*.
Takve datoteke označene su upozorenjem „dan i mjesec mogli bi biti zamijenjeni”.

**Ručni oblici naziva:** npr. `IMG-yyyyMMdd-WA*`, `Snimka yy-MM-dd HH.mm*`, `*_ddMMyyyy*`. Oznake: `yyyy` godina, `yy` dvoznamenkasta godina,
`MM` mjesec, `dd` dan, `HH` sat, `mm` minute, `ss` sekunde, `*` bilo što, `?` jedan znak, `#` jedna znamenka. Uz unos postoji provjera na primjeru naziva.

**Što se mijenja:** datum snimanja – EXIF za JPG/PNG/WEBP, datum stvaranja u MP4/MOV/3GP (mijenjaju se samo polja datuma, sadržaj ostaje isti);
datum izmjene datoteke – samo uz „Pristup svim datotekama”. Ako naziv nema vrijeme, zadržava se dosadašnje vrijeme u danu.
HEIC, MKV, AVI i sl. ne mogu spremiti datum na ovaj način (uz pristup svim datotekama mijenja im se datum izmjene).
Napomena: stvarni „datum stvaranja” datoteke na Androidu ne može se mijenjati; galerije koriste datum snimanja i datum izmjene.

## 7. Objava na Google Play – korak po korak

### 7.1 Prije prve objave
- **ID aplikacije:** `hr.zulj.duomove` (`app/build.gradle.kts` → `applicationId`). Nakon prve objave ne može se promijeniti.
  Ako ste „Duplicate Cleaner” već objavili pod `hr.zulj.duplicatecleaner` i želite zadržati korisnike, vratite taj ID prije izgradnje.
- **Naziv:** DuoMove (`tools/strings_source.py` → `app_name`, zatim `python3 tools/strings_source.py`).
- **Testiranje:** novi osobni računi (otvoreni nakon studenog 2023.) prije produkcije moraju provesti zatvoreno testiranje s najmanje
  12 testera tijekom 14 dana. Provjerite na nadzornoj ploči Play Consolea.
- **Ciljana verzija:** `targetSdk = 36` (Android 16), što Google Play traži od 31. 8. 2026.

### 7.2 Ključ za potpisivanje (jednom)
1. `keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`
   (lozinku i `upload.jks` čuvajte na sigurnom; nikad u repozitorij).
2. Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("upload.jks")) | Set-Content upload.b64`
3. GitHub → **Settings → Secrets and variables → Actions → New repository secret**:
   `SIGNING_KEYSTORE_BASE64` (sadržaj `upload.b64`), `SIGNING_STORE_PASSWORD`, `SIGNING_KEY_ALIAS` (`upload`), `SIGNING_KEY_PASSWORD`.
4. Actions → „Izgradi APK” → **Run workflow** → pod Artifacts: **DuoMove-google-play-aab** (`app-play-release.aab`).

Lokalno: datoteka `keystore.properties` u korijenu (`storeFile`, `storePassword`, `keyAlias`, `keyPassword`) i `./gradlew :app:bundlePlayRelease`.

### 7.3 Pravila privatnosti
Tekst je u `PRIVACY_POLICY.md`. Objavite ga kao javnu stranicu (npr. javni gist na gist.github.com ili Google Sites) i kopirajte poveznicu.

### 7.4 Izrada aplikacije
Play Console → **Izradi aplikaciju** → naziv *DuoMove*, zadani jezik, *Aplikacija*, *Besplatno*, prihvatite izjave.

### 7.5 Sadržaj aplikacije (Politika → Sadržaj aplikacije)
| Odjeljak | Odgovor |
|---|---|
| Pravila o privatnosti | poveznica iz 7.3 |
| Pristup aplikaciji | sve funkcije dostupne bez prijave |
| Oglasi | ne |
| Ocjena sadržaja | upitnik – *Uslužni program/alati*, sve „Ne” |
| Ciljana publika | 18+ (ili 13+), nije namijenjena djeci |
| **Sigurnost podataka** | „Prikuplja li ili dijeli aplikacija korisničke podatke?” → **Ne**. Obrazloženje: sve se obrađuje na uređaju; prijenos ide izravno na drugi uređaj korisnika na njegov zahtjev, bez developera i trećih strana (Google takav prijenos ne smatra „dijeljenjem”). |
| Financijske značajke, zdravlje, vladine aplikacije | ne |

### 7.6 Deklaracija za fotografije i videozapise (READ_MEDIA_IMAGES / READ_MEDIA_VIDEO)
**Sadržaj aplikacije → Dopuštenja za fotografije i videozapise**. Prijedlog obrazloženja:
> *DuoMove's core features require broad access to the user's photos and videos: (1) finding exact and visually identical duplicates across
> the whole library, (2) fixing the date taken of photos/videos whose date does not match the date in their file name, and (3) transferring
> the user's chosen photos and videos to their new phone over a direct Wi-Fi connection. The Android photo picker would require the user to
> select thousands of files manually. All processing is on-device; nothing is uploaded.*

### 7.7 Usluga u prvom planu (Foreground service)
**Sadržaj aplikacije → Usluge u prvom planu** → vrsta *Data sync*:
> *User-initiated file scanning and user-initiated transfer of files to the user's other device over Wi-Fi. Progress is shown in a notification
> and the user can cancel at any time.*
Po potrebi priložite kratki video (snimka zaslona) pokretanja skeniranja i prijenosa.

### 7.8 Wi-Fi uređaji u blizini / lokacija
`NEARBY_WIFI_DEVICES` je deklariran s `neverForLocation`; na Androidu 11–12 traži se `ACCESS_FINE_LOCATION` (samo za Wi-Fi Direct, `maxSdkVersion 32`).
Lokacija se ne koristi u pozadini, pa obrazac za lokaciju u pozadini nije potreban. Ako Play Console pita o lokaciji:
*„Required by Android 11–12 for Wi-Fi Direct connections between the user's phones; location is not read or stored.”*

### 7.9 Glavni unos trgovine
Tekstovi: `store/listing.md`. Ikona 512×512: `store/icon-512.png`. Istaknuta grafika 1024×500: `store/feature-graphic-1024x500.png`.
Snimke zaslona: najmanje 2 (preporuka 4–8) – sva tri dijela aplikacije (snimka: tipka za uključivanje + stišavanje).

### 7.10 Izdanje
1. **Testiranje → Interno** (ili **Zatvoreno**) → *Izradi novo izdanje* → prihvatite **Play App Signing** → uploadajte `app-play-release.aab`
   → bilješke o izdanju → *Pregledaj* → *Pokreni*.
2. Nakon testiranja: **Produkcija → Izradi novo izdanje** (ili *Promoviraj izdanje*) → države → slanje na pregled (obično 1–7 dana).
3. **Ažuriranja:** u `app/build.gradle.kts` povećajte `versionCode` (2, 3, …) i `versionName`, ponovno izgradite AAB i uploadajte.
4. Ako Google odbije zbog dopuštenja: u e-poruci piše koje; doradite obrazloženje (7.6–7.8) i pošaljite ponovno.

### 7.11 Donacije
Pravila plaćanja Google Playa dopuštaju vanjske poveznice za plaćanje (PayPal) samo za donacije oslobođene poreza (dobrotvorne udruge).
Zato je u inačici `play` gumb za donaciju isključen (`SHOW_DONATE = false` u `app/build.gradle.kts`). Siguran način na Playu je donacija preko
Google Play naplate (jednokratna kupnja „Kava”), koja se može dodati kasnije.

## 8. Dopuštenja

| Dopuštenje | Svrha |
|---|---|
| `READ_MEDIA_IMAGES/VIDEO/AUDIO` (13+), `READ_EXTERNAL_STORAGE` (11–12), `READ_MEDIA_VISUAL_USER_SELECTED` (14+) | Duplikati, ispravak datuma, slanje |
| `ACCESS_MEDIA_LOCATION` | Izvorni bajtovi fotografija (usporedba, prijenos s EXIF lokacijom) |
| `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `CHANGE_WIFI_STATE` | Lokalna veza između mobitela (ne internet) |
| `NEARBY_WIFI_DEVICES` (13+, neverForLocation), `ACCESS_FINE/COARSE_LOCATION` (11–12) | Wi-Fi Direct |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, `WAKE_LOCK`, `POST_NOTIFICATIONS` | Rad u pozadini s obaviješću |
| `<queries>` za aplikacije s ikonom | Popis aplikacija za prijenos (bez `QUERY_ALL_PACKAGES`) |
| `MANAGE_EXTERNAL_STORAGE`, `REQUEST_INSTALL_PACKAGES` | **Samo full**: cijela pohrana; instalacija primljenih aplikacija |

## 9. Arhitektura
```
core/ (čisti Kotlin, JVM testovi)
  dates/     NameDateParser (DDMM/MMDD, vrijeme, Unix vrijeme), NamePattern (ručni oblici), DateFixPlanner
  media/     Mp4Dates – izmjena datuma u mvhd/tkhd/mdhd na mjestu
  transfer/  TransferSender / TransferReceiver – kontrolna veza + 4 podatkovne, HMAC kod, provjera prostora, preskakanje postojećih
  logic/, scan/, hash/  – duplikati (kao i dosad)
app/
  datefix/   čitanje iz MediaStorea, upis EXIF/MP4/datuma izmjene, MediaStore.createWriteRequest
  transfer/  P2pLink (Wi-Fi Direct), TransferScanner, AndroidTransferSource/Sink, TransferManager, TransferService, ApkInstaller
  ui/        donja traka (Duplikati / Prijenos / Datumi), zasloni, HR/EN lokalizacija
```

## 10. Poznata ograničenja
1. Android 11+.
2. Wi-Fi Direct ne podržavaju svi uređaji; tada koristite opciju *Ista Wi-Fi mreža*. Na Androidu 11–12 mora biti uključena lokacija.
3. Inačica play bez dodanih mapa ne vidi dokumente drugih aplikacija; pri primanju ne može vratiti izvorni datum izmjene
   (datum snimanja u EXIF-u/videozapisu ostaje – za ostalo pomaže dio *Datumi*).
4. Aplikacije se prenose bez podataka i prijava; instalacija iz DuoMovea samo u inačici full.
5. Ispravak datuma: HEIC/MKV/AVI bez upisa datuma snimanja; datum izmjene samo uz pristup svim datotekama; stvarni datum stvaranja nije promjenjiv.
6. Pixel (PXL_…) u nazivu zapisuje UTC vrijeme – zato se zadano uspoređuje samo datum, ne i vrijeme.
7. Neki proizvođači gase aplikacije u pozadini – uključite „Drži zaslon upaljenim” i neograničenu potrošnju baterije.
8. Android 15+: usluge vrste dataSync ograničene su na 6 sati dnevno.
9. Brisanje medija i (bez pristupa svim datotekama) izmjena datuma uvijek prolaze kroz Androidov sistemski dijalog.
